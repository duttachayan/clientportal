import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { formatCurrency, formatDate, calculateDaysUntil } from "@/lib/utils";
import { Invoice } from "@shared/schema";

interface PaymentsListProps {
  payments: Invoice[];
  isLoading: boolean;
  viewAllLink: string;
}

export function PaymentsList({ payments, isLoading, viewAllLink }: PaymentsListProps) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 bg-white border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">Upcoming Payments</CardTitle>
      </CardHeader>
      <CardContent className="bg-white px-4 py-5 sm:p-6">
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        ) : payments.length > 0 ? (
          <div className="space-y-3">
            {payments.map((payment) => {
              const daysUntilDue = calculateDaysUntil(payment.dueDate);
              
              return (
                <div key={payment.id} className="border-b border-gray-200 pb-3">
                  <div className="flex justify-between items-center">
                    <div>
                      {/* Client name would actually come from a join, for this example we use the client ID */}
                      <p className="text-sm font-medium text-gray-900">Client ID: {payment.clientId}</p>
                      <p className="text-xs text-gray-500">
                        {payment.description || `Invoice #${payment.id}`}
                        {payment.isRecurring && " - Recurring"}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        {formatCurrency(payment.amount)}
                      </p>
                      <p className="text-xs text-gray-500">
                        {daysUntilDue <= 0 
                          ? "Due today" 
                          : daysUntilDue === 1 
                            ? "Due tomorrow" 
                            : `Due in ${daysUntilDue} days`
                        }
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-sm text-gray-500">No upcoming payments</p>
          </div>
        )}
      </CardContent>
      {payments.length > 0 && (
        <div className="bg-gray-50 px-4 py-4 sm:px-6">
          <Link href={viewAllLink}>
            <a className="text-sm font-medium text-primary hover:text-blue-600">
              View all payments <span className="material-icons text-sm align-text-bottom">arrow_forward</span>
            </a>
          </Link>
        </div>
      )}
    </div>
  );
}
