import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "./StatusBadge";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import { Website } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { getInitials } from "@/lib/utils";

interface WebsiteTableProps {
  websites: Website[];
  isLoading: boolean;
}

export function WebsiteTable({ websites, isLoading }: WebsiteTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  // Filter websites based on search query
  const filteredWebsites = websites.filter(website => 
    website.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    website.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
    website.type.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Pagination
  const totalPages = Math.ceil(filteredWebsites.length / itemsPerPage);
  const paginatedWebsites = filteredWebsites.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center flex-wrap gap-4">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Client Websites</h3>
        <div className="relative w-64">
          <Input 
            type="text" 
            placeholder="Search websites..." 
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1); // Reset to first page on search
            }}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      <div className="overflow-x-auto">
        {isLoading ? (
          <div className="p-8 space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px]">Client</TableHead>
                <TableHead>Website</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Uptime</TableHead>
                <TableHead>Speed Score</TableHead>
                <TableHead>SEO Score</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedWebsites.length > 0 ? (
                paginatedWebsites.map((website) => (
                  <TableRow key={website.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-gray-500">
                            {/* This would be the client's initials in practice */}
                            {getInitials(`Client ${website.clientId}`)}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {/* This would be the client's name in practice */}
                            Client {website.clientId}
                          </div>
                          <div className="text-sm text-gray-500">Standard Plan</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-gray-900">{website.url}</div>
                      <div className="text-sm text-gray-500">{website.type}</div>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={website.status} />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={`mr-2 font-medium text-sm ${
                          parseFloat(website.uptime || "0") > 99 
                            ? "text-green-500" 
                            : parseFloat(website.uptime || "0") > 95 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.uptime || "N/A"}%
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              parseFloat(website.uptime || "0") > 99 
                                ? "bg-green-500" 
                                : parseFloat(website.uptime || "0") > 95 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.uptime || "0"}%` }}
                          ></div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={`mr-2 font-medium text-sm ${
                          (website.pageSpeed || 0) > 85 
                            ? "text-green-500" 
                            : (website.pageSpeed || 0) > 70 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.pageSpeed || "N/A"}
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              (website.pageSpeed || 0) > 85 
                                ? "bg-green-500" 
                                : (website.pageSpeed || 0) > 70 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.pageSpeed || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={`mr-2 font-medium text-sm ${
                          (website.seoScore || 0) > 85 
                            ? "text-green-500" 
                            : (website.seoScore || 0) > 70 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.seoScore || "N/A"}
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              (website.seoScore || 0) > 85 
                                ? "bg-green-500" 
                                : (website.seoScore || 0) > 70 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.seoScore || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="link" className="text-primary hover:text-blue-700">
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <p className="text-gray-500">No websites found</p>
                    {searchQuery && (
                      <p className="text-sm text-gray-400">
                        Try adjusting your search query
                      </p>
                    )}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </div>
      
      {/* Pagination */}
      {!isLoading && filteredWebsites.length > 0 && (
        <div className="bg-gray-50 px-4 py-3 flex items-center justify-between sm:px-6">
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span>{" "}
                to{" "}
                <span className="font-medium">
                  {Math.min(currentPage * itemsPerPage, filteredWebsites.length)}
                </span>{" "}
                of <span className="font-medium">{filteredWebsites.length}</span> websites
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <Button
                  variant="outline"
                  size="sm"
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <span className="sr-only">Previous</span>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                {/* Page numbers */}
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    className={`relative inline-flex items-center px-4 py-2 text-sm font-medium ${
                      currentPage === page
                        ? "bg-primary text-white border-primary z-10"
                        : "bg-white text-gray-500 hover:bg-gray-50"
                    }`}
                    onClick={() => setCurrentPage(page)}
                  >
                    {page}
                  </Button>
                ))}
                
                <Button
                  variant="outline"
                  size="sm"
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                  onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  <span className="sr-only">Next</span>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
