import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "./StatusBadge";
import { Link } from "wouter";
import { formatTimeAgo } from "@/lib/utils";
import { Ticket } from "@shared/schema";

interface TicketsListProps {
  tickets: Ticket[];
  isLoading: boolean;
  viewAllLink: string;
}

export function TicketsList({ tickets, isLoading, viewAllLink }: TicketsListProps) {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 bg-white border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">Recent Tickets</CardTitle>
      </CardHeader>
      <CardContent className="bg-white px-4 py-5 sm:p-6">
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : tickets.length > 0 ? (
          <div className="space-y-3">
            {tickets.map((ticket) => (
              <div key={ticket.id} className="border-b border-gray-200 pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      #{ticket.id} - {ticket.title}
                    </p>
                    {/* Client name would actually come from a join, for this example we use the client ID */}
                    <p className="text-xs text-gray-500">Client ID: {ticket.clientId}</p>
                  </div>
                  <div className="flex space-x-2">
                    <StatusBadge status={ticket.status} />
                    {ticket.priority === "high" || ticket.priority === "urgent" ? (
                      <StatusBadge status={ticket.priority} />
                    ) : null}
                  </div>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Updated {formatTimeAgo(ticket.updatedAt)}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-sm text-gray-500">No tickets to display</p>
          </div>
        )}
      </CardContent>
      {tickets.length > 0 && (
        <div className="bg-gray-50 px-4 py-4 sm:px-6">
          <Link href={viewAllLink}>
            <a className="text-sm font-medium text-primary hover:text-blue-600">
              View all tickets <span className="material-icons text-sm align-text-bottom">arrow_forward</span>
            </a>
          </Link>
        </div>
      )}
    </div>
  );
}
