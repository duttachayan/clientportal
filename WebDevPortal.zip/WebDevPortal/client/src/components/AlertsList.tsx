import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { formatTimeAgo } from "@/lib/utils";
import { Alert } from "@shared/schema";

interface AlertsListProps {
  alerts: Alert[];
  isLoading: boolean;
  viewAllLink: string;
}

export function AlertsList({ alerts, isLoading, viewAllLink }: AlertsListProps) {
  // Returns the appropriate icon based on alert type
  const getAlertIcon = (type: string) => {
    switch (type) {
      case "domain_expiry":
        return "warning";
      case "ssl_expiry":
        return "error";
      case "server_maintenance":
        return "info";
      case "performance_issue":
        return "warning";
      default:
        return "info";
    }
  };
  
  // Returns the appropriate color classes based on alert type
  const getAlertColor = (type: string) => {
    switch (type) {
      case "domain_expiry":
        return "border-warning/50 bg-warning/5 text-warning";
      case "ssl_expiry":
        return "border-error/50 bg-error/5 text-error";
      case "server_maintenance":
        return "border-primary/50 bg-primary/5 text-primary";
      case "performance_issue":
        return "border-warning/50 bg-warning/5 text-warning";
      default:
        return "border-primary/50 bg-primary/5 text-primary";
    }
  };
  
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 bg-white border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">Recent Alerts</CardTitle>
      </CardHeader>
      <CardContent className="bg-white px-4 py-5 sm:p-6">
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        ) : alerts.length > 0 ? (
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div 
                key={alert.id} 
                className={`flex p-3 rounded-md border ${getAlertColor(alert.type)}`}
              >
                <span className={`material-icons mr-3 ${getAlertColor(alert.type).split(" ").pop()}`}>
                  {getAlertIcon(alert.type)}
                </span>
                <div>
                  <p className="text-sm font-medium text-gray-900">{alert.title}</p>
                  <p className="text-xs text-gray-500">{alert.description}</p>
                  {alert.dueDate && (
                    <p className="text-xs text-gray-500 mt-1">
                      {alert.type.includes("expiry") ? 
                        `Expires ${formatTimeAgo(alert.dueDate)}` : 
                        `Due ${formatTimeAgo(alert.dueDate)}`
                      }
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-sm text-gray-500">No alerts to display</p>
          </div>
        )}
      </CardContent>
      {alerts.length > 0 && (
        <div className="bg-gray-50 px-4 py-4 sm:px-6">
          <Link href={viewAllLink}>
            <a className="text-sm font-medium text-primary hover:text-blue-600">
              View all alerts <span className="material-icons text-sm align-text-bottom">arrow_forward</span>
            </a>
          </Link>
        </div>
      )}
    </div>
  );
}
