import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { useSidebarStore } from "@/store";
import { 
  LogOut, 
  Home, 
  Users, 
  Briefcase, 
  TicketCheck, 
  Receipt, 
  Settings,
  Globe,
  HelpCircle,
  CreditCard,
  UserCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick?: () => void;
}

const SidebarItem = ({ href, icon, label, active, onClick }: SidebarItemProps) => {
  return (
    <Link href={href} className="flex items-center">
      <div 
        className={cn(
          "sidebar-item group flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer",
          active 
            ? "bg-primary/10 border-l-[3px] border-primary text-gray-900" 
            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        )}
        onClick={onClick}
      >
        <div className={cn(
          "mr-3",
          active ? "text-primary" : "text-gray-500"
        )}>
          {icon}
        </div>
        <span>{label}</span>
      </div>
    </Link>
  );
};

export function SidebarNav() {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const { isOpen, close } = useSidebarStore();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isAdmin = user?.role === "admin";
  const basePathPrefix = isAdmin ? "/admin" : "/client";

  const iconSize = 18;

  const adminNavItems = [
    { href: "/admin/dashboard", icon: <Home size={iconSize} />, label: "Dashboard" },
    { href: "/admin/clients", icon: <Users size={iconSize} />, label: "Clients" },
    { href: "/admin/projects", icon: <Briefcase size={iconSize} />, label: "Projects" },
    { href: "/admin/tickets", icon: <TicketCheck size={iconSize} />, label: "Tickets" },
    { href: "/admin/invoices", icon: <Receipt size={iconSize} />, label: "Invoices" },
    { href: "/admin/settings", icon: <Settings size={iconSize} />, label: "Settings" },
  ];

  const clientNavItems = [
    { href: "/client/dashboard", icon: <Home size={iconSize} />, label: "My Dashboard" },
    { href: "/client/websites", icon: <Globe size={iconSize} />, label: "My Websites" },
    { href: "/client/tickets", icon: <HelpCircle size={iconSize} />, label: "Support Tickets" },
    { href: "/client/invoices", icon: <CreditCard size={iconSize} />, label: "Invoices" },
    { href: "/client/account", icon: <UserCircle size={iconSize} />, label: "My Account" },
  ];

  const navItems = isAdmin ? adminNavItems : clientNavItems;

  return (
    <>
      {/* Desktop sidebar */}
      <div id="sidebar" className={cn(
        "md:flex md:flex-shrink-0",
        isOpen ? "fixed inset-0 z-40 flex" : "hidden"
      )}>
        <div className="flex flex-col w-64 bg-white border-r border-gray-200">
          <div className="flex items-center justify-center h-16 border-b border-gray-200">
            <h1 className="text-xl font-bold text-primary">WebAgency Portal</h1>
          </div>

          <div className="flex-grow flex flex-col pt-5 pb-4 overflow-y-auto">
            <div className="px-4 mb-6">
              <div className="flex items-center">
                <div className={cn(
                  "h-8 w-8 rounded-full text-white flex items-center justify-center",
                  isAdmin ? "bg-primary" : "bg-secondary"
                )}>
                  {isAdmin ? 
                    <Settings size={14} /> : 
                    <UserCircle size={14} />
                  }
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                  <p className="text-xs font-medium text-gray-500">
                    {isAdmin ? "Administrator" : "Client"}
                  </p>
                </div>
              </div>
            </div>

            <nav className="flex-1 px-2 space-y-1">
              {navItems.map((item) => (
                <SidebarItem
                  key={item.href}
                  href={item.href}
                  icon={item.icon}
                  label={item.label}
                  active={location === item.href}
                  onClick={() => close()}
                />
              ))}
              <div className="mt-auto pb-4">
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => logoutMutation.mutate()}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </>
  );
}