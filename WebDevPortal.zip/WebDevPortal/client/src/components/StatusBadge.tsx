import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  // Define color mapping for different status types
  const getStatusColor = (status: string) => {
    const statusMap: Record<string, string> = {
      // Website statuses
      healthy: "bg-green-100 text-green-800",
      warning: "bg-yellow-100 text-yellow-800",
      critical: "bg-red-100 text-red-800",
      offline: "bg-gray-100 text-gray-800",
      
      // Project statuses
      planning: "bg-purple-100 text-purple-800",
      in_progress: "bg-blue-100 text-blue-800",
      review: "bg-amber-100 text-amber-800",
      completed: "bg-green-100 text-green-800",
      on_hold: "bg-gray-100 text-gray-800",
      
      // Ticket statuses
      open: "bg-blue-100 text-blue-800",
      resolved: "bg-green-100 text-green-800",
      closed: "bg-gray-100 text-gray-800",
      
      // Ticket priorities
      low: "bg-blue-100 text-blue-800",
      medium: "bg-yellow-100 text-yellow-800",
      high: "bg-orange-100 text-orange-800",
      urgent: "bg-red-100 text-red-800",
      
      // Invoice statuses
      draft: "bg-gray-100 text-gray-800",
      sent: "bg-blue-100 text-blue-800",
      paid: "bg-green-100 text-green-800",
      overdue: "bg-red-100 text-red-800",
      cancelled: "bg-gray-100 text-gray-800",
      
      // Package types
      basic: "bg-gray-100 text-gray-800",
      standard: "bg-blue-100 text-blue-800",
      premium: "bg-purple-100 text-purple-800",
      custom: "bg-amber-100 text-amber-800"
    };
    
    return statusMap[status.toLowerCase()] || "bg-gray-100 text-gray-800";
  };
  
  // Format the status text for display (capitalize, replace underscores with spaces)
  const formatStatus = (status: string) => {
    return status
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };
  
  return (
    <span className={cn(
      "px-2 inline-flex text-xs leading-5 font-semibold rounded-full",
      getStatusColor(status),
      className
    )}>
      {formatStatus(status)}
    </span>
  );
}
