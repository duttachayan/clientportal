import { useSidebarStore } from "@/store";
import { useAuth } from "@/hooks/use-auth";
import { Menu } from "lucide-react";
import { getInitials } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface MobileHeaderProps {
  title: string;
}

export function MobileHeader({ title }: MobileHeaderProps) {
  const { toggle } = useSidebarStore();
  const { user } = useAuth();
  
  return (
    <div className="md:hidden p-4 bg-white border-b border-gray-200 flex items-center justify-between">
      <button
        type="button"
        className="inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900 focus:outline-none"
        onClick={toggle}
      >
        <Menu className="h-6 w-6" />
      </button>
      
      <div>
        <h1 className="text-lg font-bold text-primary">{title}</h1>
      </div>
      
      <div>
        <Avatar className="h-8 w-8 bg-primary text-white">
          <AvatarFallback>{user?.name ? getInitials(user.name) : "U"}</AvatarFallback>
        </Avatar>
      </div>
    </div>
  );
}
