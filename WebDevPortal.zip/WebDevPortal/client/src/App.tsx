import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import AuthPage from "@/pages/auth-page";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminClients from "@/pages/admin/clients";
import AdminProjects from "@/pages/admin/projects";
import AdminTickets from "@/pages/admin/tickets";
import AdminInvoices from "@/pages/admin/invoices";
import AdminSettings from "@/pages/admin/settings";

// Client pages
import ClientDashboard from "@/pages/client/dashboard";
import ClientWebsites from "@/pages/client/websites";
import ClientTickets from "@/pages/client/tickets";
import ClientInvoices from "@/pages/client/invoices";
import ClientAccount from "@/pages/client/account";

function Router() {
  return (
    <Switch>
      {/* Auth routes */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Admin routes */}
      <ProtectedRoute path="/" component={AdminDashboard} />
      <ProtectedRoute path="/admin/dashboard" component={AdminDashboard} />
      <ProtectedRoute path="/admin/clients" component={AdminClients} />
      <ProtectedRoute path="/admin/projects" component={AdminProjects} />
      <ProtectedRoute path="/admin/tickets" component={AdminTickets} />
      <ProtectedRoute path="/admin/invoices" component={AdminInvoices} />
      <ProtectedRoute path="/admin/settings" component={AdminSettings} />
      
      {/* Client routes */}
      <ProtectedRoute path="/client/dashboard" component={ClientDashboard} />
      <ProtectedRoute path="/client/websites" component={ClientWebsites} />
      <ProtectedRoute path="/client/tickets" component={ClientTickets} />
      <ProtectedRoute path="/client/invoices" component={ClientInvoices} />
      <ProtectedRoute path="/client/account" component={ClientAccount} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
