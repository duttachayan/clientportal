import { useAuth } from "@/hooks/use-auth";
import { useLocation, useRoute } from "wouter";
import { SidebarNav } from "@/components/SidebarNav";
import { MobileHeader } from "@/components/MobileHeader";
import { useSidebarStore } from "@/store";
import { useEffect } from "react";

type DashboardLayoutProps = {
  children: React.ReactNode;
  title: string;
};

export function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const [isAdminDashboard] = useRoute("/admin/dashboard");
  const [isClientDashboard] = useRoute("/client/dashboard");
  const { isOpen, close } = useSidebarStore();
  
  useEffect(() => {
    // Redirect to the appropriate dashboard based on role
    if (user && location === "/") {
      if (user.role === "admin") {
        navigate("/admin/dashboard");
      } else {
        navigate("/client/dashboard");
      }
    }
    
    // Close sidebar on route change for mobile
    close();
  }, [user, location, navigate, close]);
  
  // Handle role-based dashboard display
  useEffect(() => {
    if (user) {
      const isAdmin = user.role === "admin";
      
      if (isAdmin && isClientDashboard) {
        navigate("/admin/dashboard");
      } else if (!isAdmin && isAdminDashboard) {
        navigate("/client/dashboard");
      }
    }
  }, [user, isAdminDashboard, isClientDashboard, navigate]);
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <SidebarNav />
      
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <MobileHeader title={title} />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900 mb-6">{title}</h1>
              {children}
            </div>
          </div>
        </main>
      </div>
      
      {/* Mobile sidebar overlay */}
      {isOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-gray-600 bg-opacity-75 z-20"
          onClick={close}
        />
      )}
    </div>
  );
}

export default DashboardLayout;
