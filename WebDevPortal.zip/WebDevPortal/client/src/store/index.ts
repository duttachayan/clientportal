import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SidebarState {
  isOpen: boolean;
  toggle: () => void;
  close: () => void;
  open: () => void;
}

export const useSidebarStore = create<SidebarState>((set) => ({
  isOpen: false,
  toggle: () => set((state) => ({ isOpen: !state.isOpen })),
  close: () => set({ isOpen: false }),
  open: () => set({ isOpen: true }),
}));

interface ThemeState {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'light',
      toggleTheme: () => 
        set((state) => ({ 
          theme: state.theme === 'light' ? 'dark' : 'light' 
        })),
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: 'theme-storage',
    }
  )
);

interface FilterState {
  clientFilter: number | null;
  statusFilter: string | null;
  searchTerm: string;
  setClientFilter: (clientId: number | null) => void;
  setStatusFilter: (status: string | null) => void;
  setSearchTerm: (term: string) => void;
  resetFilters: () => void;
}

export const useFilterStore = create<FilterState>((set) => ({
  clientFilter: null,
  statusFilter: null,
  searchTerm: '',
  setClientFilter: (clientId) => set({ clientFilter: clientId }),
  setStatusFilter: (status) => set({ statusFilter: status }),
  setSearchTerm: (term) => set({ searchTerm: term }),
  resetFilters: () => set({ clientFilter: null, statusFilter: null, searchTerm: '' }),
}));
