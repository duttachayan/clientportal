import { useState } from "react";
import DashboardLayout from "@/layouts/Dashboard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save } from "lucide-react";

const brandingSchema = z.object({
  companyName: z.string().min(2, "Company name is required"),
  logoUrl: z.string().url("Please enter a valid URL").or(z.string().length(0)),
  primaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, "Please enter a valid hex color"),
  secondaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, "Please enter a valid hex color"),
  emailFooter: z.string(),
});

const emailSchema = z.object({
  senderName: z.string().min(2, "Sender name is required"),
  senderEmail: z.string().email("Please enter a valid email"),
  emailSignature: z.string(),
  invoiceTemplate: z.string(),
  welcomeTemplate: z.string(),
  ticketTemplate: z.string(),
});

const integrationSchema = z.object({
  allowRegistration: z.boolean().default(true),
  googleAnalyticsId: z.string(),
  stripeEnabled: z.boolean(),
  stripeApiKey: z.string().optional(),
  zapierEnabled: z.boolean(),
  zapierWebhook: z.string().url("Please enter a valid URL").optional(),
  slackEnabled: z.boolean(),
  slackWebhook: z.string().url("Please enter a valid URL").optional(),
});

type BrandingFormValues = z.infer<typeof brandingSchema>;
type EmailFormValues = z.infer<typeof emailSchema>;
type IntegrationFormValues = z.infer<typeof integrationSchema>;

export default function AdminSettings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("branding");

  // Branding Form
  const brandingForm = useForm<BrandingFormValues>({
    resolver: zodResolver(brandingSchema),
    defaultValues: {
      companyName: "WebAgency",
      logoUrl: "",
      primaryColor: "#3B82F6",
      secondaryColor: "#6366F1",
      emailFooter: "© 2023 WebAgency. All rights reserved.",
    },
  });

  const [savingBranding, setSavingBranding] = useState(false);

  const onSaveBranding = (data: BrandingFormValues) => {
    setSavingBranding(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Branding settings saved",
        description: "Your branding settings have been updated successfully",
      });
      setSavingBranding(false);
    }, 1000);
  };

  // Email Form
  const emailForm = useForm<EmailFormValues>({
    resolver: zodResolver(emailSchema),
    defaultValues: {
      senderName: "WebAgency Support",
      senderEmail: "support@webagency.com",
      emailSignature: "Thanks,\nThe WebAgency Team",
      invoiceTemplate: "<p>Your invoice {{invoice_number}} is ready.</p>",
      welcomeTemplate: "<p>Welcome to WebAgency, {{client_name}}!</p>",
      ticketTemplate: "<p>Your support ticket {{ticket_id}} has been created.</p>",
    },
  });

  const [savingEmail, setSavingEmail] = useState(false);

  const onSaveEmail = (data: EmailFormValues) => {
    setSavingEmail(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Email settings saved",
        description: "Your email settings have been updated successfully",
      });
      setSavingEmail(false);
    }, 1000);
  };

  // Integration Form
  const integrationForm = useForm<IntegrationFormValues>({
    resolver: zodResolver(integrationSchema),
    defaultValues: {
      googleAnalyticsId: "",
      stripeEnabled: false,
      stripeApiKey: "",
      zapierEnabled: false,
      zapierWebhook: "",
      slackEnabled: false,
      slackWebhook: "",
    },
  });

  const [savingIntegration, setSavingIntegration] = useState(false);

  const onSaveIntegration = (data: IntegrationFormValues) => {
    setSavingIntegration(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Integration settings saved",
        description: "Your integration settings have been updated successfully",
      });
      setSavingIntegration(false);
    }, 1000);
  };

  const watchStripeEnabled = integrationForm.watch("stripeEnabled");
  const watchZapierEnabled = integrationForm.watch("zapierEnabled");
  const watchSlackEnabled = integrationForm.watch("slackEnabled");

  return (
    <DashboardLayout title="Settings">
      <Tabs defaultValue="branding" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
          <TabsTrigger value="branding">Branding</TabsTrigger>
          <TabsTrigger value="email">Email Templates</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          {/* Branding Settings */}
          <TabsContent value="branding">
            <Card>
              <CardHeader>
                <CardTitle>Branding Settings</CardTitle>
                <CardDescription>
                  Customize your agency's branding that appears in the portal and client communications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...brandingForm}>
                  <form onSubmit={brandingForm.handleSubmit(onSaveBranding)} className="space-y-6">
                    <FormField
                      control={brandingForm.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter company name" {...field} />
                          </FormControl>
                          <FormDescription>
                            This will appear in the portal and all communications
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={brandingForm.control}
                      name="logoUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Logo URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://yourdomain.com/logo.png" {...field} />
                          </FormControl>
                          <FormDescription>
                            URL to your company logo (recommended size: 200x50px)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={brandingForm.control}
                        name="primaryColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Primary Color</FormLabel>
                            <div className="flex items-center gap-2">
                              <Input type="color" {...field} className="w-12 h-10 p-1" />
                              <Input {...field} className="flex-1" />
                            </div>
                            <FormDescription>
                              Main brand color for buttons and accents
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={brandingForm.control}
                        name="secondaryColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Secondary Color</FormLabel>
                            <div className="flex items-center gap-2">
                              <Input type="color" {...field} className="w-12 h-10 p-1" />
                              <Input {...field} className="flex-1" />
                            </div>
                            <FormDescription>
                              Secondary color for gradients and highlights
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={brandingForm.control}
                      name="emailFooter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Footer</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Enter footer text for emails"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            This text will appear at the bottom of all emails
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end">
                      <Button type="submit" disabled={savingBranding}>
                        {savingBranding ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Branding Settings
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Email Templates */}
          <TabsContent value="email">
            <Card>
              <CardHeader>
                <CardTitle>Email Templates</CardTitle>
                <CardDescription>
                  Customize the templates used for various automated emails
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...emailForm}>
                  <form onSubmit={emailForm.handleSubmit(onSaveEmail)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={emailForm.control}
                        name="senderName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sender Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your Company Name" {...field} />
                            </FormControl>
                            <FormDescription>
                              Name that appears in the "From" field
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={emailForm.control}
                        name="senderEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sender Email</FormLabel>
                            <FormControl>
                              <Input placeholder="support@yourcompany.com" {...field} />
                            </FormControl>
                            <FormDescription>
                              Email address that appears in the "From" field
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={emailForm.control}
                      name="emailSignature"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Signature</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Your email signature"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            This signature will be included in all emails
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="invoiceTemplate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Invoice Email Template</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Template for invoice emails"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Use variables like &#123;invoice_number&#125;, &#123;amount&#125;, &#123;due_date&#125;
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="welcomeTemplate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Welcome Email Template</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Template for welcome emails"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Use variables like {{client_name}}, {{login_url}}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={emailForm.control}
                      name="ticketTemplate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Support Ticket Template</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Template for support ticket emails"
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Use variables like {{ticket_id}}, {{ticket_title}}, {{ticket_description}}
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end">
                      <Button type="submit" disabled={savingEmail}>
                        {savingEmail ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Email Templates
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Integrations */}
          <TabsContent value="integrations">
            <Card>
              <CardHeader>
                <CardTitle>Third-Party Integrations</CardTitle>
                <CardDescription>
                  Connect your portal with external services and tools
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...integrationForm}>
                  <form onSubmit={integrationForm.handleSubmit(onSaveIntegration)} className="space-y-6">
                    <FormField
                      control={integrationForm.control}
                      name="googleAnalyticsId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Google Analytics ID</FormLabel>
                          <FormControl>
                            <Input placeholder="GA-XXXXXXXXXX" {...field} />
                          </FormControl>
                          <FormDescription>
                            Add Google Analytics to track portal usage
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={integrationForm.control}
                      name="stripeEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Stripe Payment Integration</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Enable Stripe for processing invoice payments
                            </div>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {watchStripeEnabled && (
                      <FormField
                        control={integrationForm.control}
                        name="stripeApiKey"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Stripe API Key</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="sk_live_XXXXXXXXXXXXX" {...field} />
                            </FormControl>
                            <FormDescription>
                              Your Stripe secret key (begins with sk_live_)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={integrationForm.control}
                      name="zapierEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Zapier Integration</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Connect portal events to thousands of apps via Zapier
                            </div>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {watchZapierEnabled && (
                      <FormField
                        control={integrationForm.control}
                        name="zapierWebhook"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Zapier Webhook URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://hooks.zapier.com/..." {...field} />
                            </FormControl>
                            <FormDescription>
                              The webhook URL provided by your Zapier trigger
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={integrationForm.control}
                      name="slackEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Slack Notifications</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Send notifications to a Slack channel
                            </div>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {watchSlackEnabled && (
                      <FormField
                        control={integrationForm.control}
                        name="slackWebhook"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Slack Webhook URL</FormLabel>
                            <FormControl>
                              <Input placeholder="https://hooks.slack.com/services/..." {...field} />
                            </FormControl>
                            <FormDescription>
                              The incoming webhook URL from your Slack workspace
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <div className="flex justify-end">
                      <Button type="submit" disabled={savingIntegration}>
                        {savingIntegration ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="mr-2 h-4 w-4" />
                            Save Integration Settings
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </DashboardLayout>
  );
}