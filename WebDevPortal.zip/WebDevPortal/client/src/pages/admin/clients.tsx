import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/StatusBadge";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getInitials } from "@/lib/utils";
import { Loader2, PlusCircle, Search, Mail, Phone, Building } from "lucide-react";
import { getStatusColor } from "@/lib/utils";
import { Client } from "@shared/schema";

const createClientSchema = z.object({
  userId: z.number().optional(),
  companyName: z.string().min(2, "Company name is required"),
  contactPerson: z.string().min(2, "Contact person name is required"),
  email: z.string().email("Please enter a valid email"),
  phone: z.string().optional(),
  address: z.string().optional(),
  packageType: z.enum(["basic", "standard", "premium", "custom"]),
  notes: z.string().optional(),
  customPackageName: z.string().optional(), // Added customPackageName field
});

type CreateClientFormValues = z.infer<typeof createClientSchema>;

export default function AdminClients() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreatingClient, setIsCreatingClient] = useState(false);
  const { toast } = useToast();

  const { data: clients, isLoading } = useQuery({
    queryKey: ["/api/clients"],
  });

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  const filteredClients = clients?.filter(client =>
    client.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.contactPerson.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const createClientForm = useForm<CreateClientFormValues>({
    resolver: zodResolver(createClientSchema),
    defaultValues: {
      companyName: "",
      contactPerson: "",
      email: "",
      phone: "",
      address: "",
      packageType: "basic",
      notes: "",
      customPackageName: "", // Added default value for customPackageName
    },
  });

  const createClientMutation = useMutation({
    mutationFn: async (data: CreateClientFormValues) => {
      const res = await apiRequest("POST", "/api/clients", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({
        title: "Client created",
        description: "The client has been created successfully",
      });
      setIsCreatingClient(false);
      createClientForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating client",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onCreateClient = (data: CreateClientFormValues) => {
    createClientMutation.mutate(data);
  };

  return (
    <DashboardLayout title="Clients">
      <div className="flex justify-between items-center mb-6">
        <div className="relative w-72">
          <Input
            placeholder="Search clients..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>

        <Dialog open={isCreatingClient} onOpenChange={setIsCreatingClient}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-blue-600">
              <PlusCircle className="mr-2 h-4 w-4" />
              Add New Client
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg" aria-describedby="client-form-description">
            <DialogHeader>
              <DialogTitle>Create New Client</DialogTitle>
            </DialogHeader>
            <Form {...createClientForm}>
              <form onSubmit={createClientForm.handleSubmit(onCreateClient)} className="space-y-4">
                <FormField
                  control={createClientForm.control}
                  name="companyName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter company name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createClientForm.control}
                  name="contactPerson"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Person</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter contact person name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createClientForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="Enter email address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createClientForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter phone number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createClientForm.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={createClientForm.control}
                  name="packageType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Package Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a package type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="basic">Basic</SelectItem>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="premium">Premium</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {createClientForm.watch("packageType") === "custom" && (
                  <FormField
                    control={createClientForm.control}
                    name="customPackageName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Custom Package Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter custom package name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={createClientForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes about the client" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreatingClient(false)}
                    className="mr-2"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createClientMutation.isPending}
                  >
                    {createClientMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Create Client"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="h-24 bg-gray-100 rounded-t-lg"></CardHeader>
              <CardContent className="pt-4">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-5/6 mb-2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClients.length > 0 ? (
            filteredClients.map((client: Client) => (
              <Card key={client.id} className="overflow-hidden">
                <CardHeader className="pb-4 bg-gray-50 border-b">
                  <div className="flex items-center">
                    <div className="h-12 w-12 rounded-full bg-primary text-white flex items-center justify-center mr-4">
                      <span className="text-sm font-medium">{getInitials(client.companyName)}</span>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{client.companyName}</h3>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(client.packageType)}`}>
                        {client.packageType.charAt(0).toUpperCase() + client.packageType.slice(1)} Plan
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Building className="h-4 w-4 text-muted-foreground mr-2" />
                      <span className="text-sm">{client.contactPerson}</span>
                    </div>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 text-muted-foreground mr-2" />
                      <span className="text-sm">{client.email}</span>
                    </div>
                    {client.phone && (
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                        <span className="text-sm">{client.phone}</span>
                      </div>
                    )}
                  </div>
                  <div className="mt-4 pt-4 border-t flex justify-between">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">Edit</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Edit Client</DialogTitle>
                        </DialogHeader>
                        <Form {...createClientForm}>
                          <form onSubmit={createClientForm.handleSubmit(data => 
                            updateClientMutation.mutate({ id: client.id, ...data })
                          )} className="space-y-4">
                            {/* Reuse the same form fields as create form */}
                            <FormField
                              control={createClientForm.control}
                              name="logo"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Logo URL</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Enter logo URL" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </form>
                        </Form>
                      </DialogContent>
                    </Dialog>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">View Details</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-lg">
                        <DialogHeader>
                          <DialogTitle>Client Details</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-medium">Company Name</h4>
                            <p className="text-sm text-gray-600">{client.companyName}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Contact Person</h4>
                            <p className="text-sm text-gray-600">{client.contactPerson}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Email</h4>
                            <p className="text-sm text-gray-600">{client.email}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Phone</h4>
                            <p className="text-sm text-gray-600">{client.phone || 'N/A'}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Address</h4>
                            <p className="text-sm text-gray-600">{client.address || 'N/A'}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Package Type</h4>
                            <p className="text-sm text-gray-600">{client.packageType}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Notes</h4>
                            <p className="text-sm text-gray-600">{client.notes || 'N/A'}</p>
                          </div>
                          <div>
                            <h4 className="font-medium mb-2">Projects</h4>
                            {projects?.filter(p => p.clientId === client.id).map(project => (
                              <div key={project.id} className="mb-2 p-2 border rounded">
                                <p className="font-medium">{project.name}</p>
                                <StatusBadge status={project.status} />
                              </div>
                            ))}
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        // Navigate to client projects
                        window.location.href = `/admin/projects?clientId=${client.id}`;
                      }}
                    >
                      Projects
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full flex items-center justify-center h-64 bg-gray-50 rounded-lg">
              <div className="text-center">
                <p className="text-lg font-medium text-gray-900">No clients found</p>
                <p className="text-sm text-gray-500">Try adjusting your search or create a new client</p>
              </div>
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  );
}