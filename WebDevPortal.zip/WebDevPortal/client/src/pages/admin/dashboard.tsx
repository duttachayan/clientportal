import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Plus, Users, Briefcase, TicketCheck, AlertCircle } from "lucide-react";
import { StatsCard } from "@/components/StatsCard";
import { AlertsList } from "@/components/AlertsList";
import { TicketsList } from "@/components/TicketsList";
import { PaymentsList } from "@/components/PaymentsList";
import { WebsiteTable } from "@/components/WebsiteTable";

export default function AdminDashboard() {
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
  });

  const { data: alerts, isLoading: isLoadingAlerts } = useQuery({
    queryKey: ["/api/alerts"],
  });

  const { data: tickets, isLoading: isLoadingTickets } = useQuery({
    queryKey: ["/api/tickets"],
  });

  const { data: websites, isLoading: isLoadingWebsites } = useQuery({
    queryKey: ["/api/websites"],
  });

  const { data: invoices, isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/invoices"],
  });

  // Filter the most recent alerts, tickets, and upcoming payments
  const recentAlerts = alerts?.slice(0, 3) || [];
  const recentTickets = tickets?.slice(0, 3) || [];
  const upcomingPayments = invoices?.filter(invoice => 
    invoice.status === "sent" || invoice.status === "overdue"
  ).slice(0, 3) || [];

  return (
    <DashboardLayout title="Admin Dashboard">
      <div className="flex justify-between items-center mb-6">
        <div className="flex space-x-3">
          <Button 
            className="bg-primary hover:bg-blue-600"
            onClick={() => window.location.href = '/admin/clients'}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Client
          </Button>
          <Button 
            className="bg-primary hover:bg-blue-600"
            onClick={() => window.location.href = '/admin/projects'}
          >
            <Plus className="mr-2 h-4 w-4" />
            New Project
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {isLoadingStats ? (
          // Loading skeletons
          <>
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </>
        ) : (
          <>
            <StatsCard
              title="Total Clients"
              value={stats?.totalClients || 0}
              icon={<Users size={24} />}
              color="primary"
              link="/admin/clients"
            />
            <StatsCard
              title="Active Projects"
              value={stats?.activeProjects || 0}
              icon={<Briefcase size={24} />}
              color="secondary"
              link="/admin/projects"
            />
            <StatsCard
              title="Open Tickets"
              value={stats?.openTickets || 0}
              icon={<TicketCheck size={24} />}
              color="accent"
              link="/admin/tickets"
            />
            <StatsCard
              title="Expiring Soon"
              value={stats?.expiringSoon || 0}
              icon={<AlertCircle size={24} />}
              color="warning"
              link="/admin/clients"
            />
          </>
        )}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Recent Alerts */}
        <AlertsList
          alerts={recentAlerts}
          isLoading={isLoadingAlerts}
          viewAllLink="/admin/alerts"
        />

        {/* Recent Tickets */}
        <TicketsList
          tickets={recentTickets}
          isLoading={isLoadingTickets}
          viewAllLink="/admin/tickets"
        />

        {/* Upcoming Payments */}
        <PaymentsList
          payments={upcomingPayments}
          isLoading={isLoadingInvoices}
          viewAllLink="/admin/invoices"
        />
      </div>

      {/* Client Websites Table */}
      <div className="mt-8">
        <WebsiteTable
          websites={websites || []}
          isLoading={isLoadingWebsites}
        />
      </div>
    </DashboardLayout>
  );
}