import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { StatsCard } from "@/components/StatsCard";
import { AlertsList } from "@/components/AlertsList";
import { TicketsList } from "@/components/TicketsList";
import { PaymentsList } from "@/components/PaymentsList";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { StatusBadge } from "@/components/StatusBadge";
import { formatDate } from "@/lib/utils";
import { Plus, ExternalLink, Globe, Briefcase, HelpCircle, Receipt, ChevronRight } from "lucide-react";
import { Link } from "wouter";

export default function ClientDashboard() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
  });
  
  const { data: alerts, isLoading: isLoadingAlerts } = useQuery({
    queryKey: ["/api/alerts"],
  });
  
  const { data: tickets, isLoading: isLoadingTickets } = useQuery({
    queryKey: ["/api/tickets"],
  });
  
  const { data: websites, isLoading: isLoadingWebsites } = useQuery({
    queryKey: ["/api/websites"],
  });
  
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ["/api/projects"],
  });
  
  const { data: invoices, isLoading: isLoadingInvoices } = useQuery({
    queryKey: ["/api/invoices"],
  });
  
  // Filter the most recent alerts, tickets, and upcoming payments
  const recentAlerts = alerts?.slice(0, 3) || [];
  const recentTickets = tickets?.slice(0, 3) || [];
  const upcomingPayments = invoices?.filter(invoice => 
    invoice.status === "sent" || invoice.status === "overdue"
  ).slice(0, 3) || [];
  
  // Filter active projects
  const activeProjects = projects?.filter(project => 
    project.status === "in_progress" || project.status === "planning" || project.status === "review"
  ).slice(0, 3) || [];
  
  return (
    <DashboardLayout title="My Dashboard">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {isLoadingStats ? (
          // Loading skeletons
          <>
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </>
        ) : (
          <>
            <StatsCard
              title="My Websites"
              value={stats?.websites || 0}
              icon={<Globe size={24} />}
              color="primary"
              link="/client/websites"
            />
            <StatsCard
              title="Active Projects"
              value={stats?.activeProjects || 0}
              icon={<Briefcase size={24} />}
              color="secondary"
              link="/client/websites"
            />
            <StatsCard
              title="Open Tickets"
              value={stats?.openTickets || 0}
              icon={<HelpCircle size={24} />}
              color="accent"
              link="/client/tickets"
            />
            <StatsCard
              title="Unpaid Invoices"
              value={stats?.unpaidInvoices || 0}
              icon={<Receipt size={24} />}
              color="warning"
              link="/client/invoices"
            />
          </>
        )}
      </div>
      
      {/* Main Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Recent Alerts */}
        <AlertsList
          alerts={recentAlerts}
          isLoading={isLoadingAlerts}
          viewAllLink="/client/websites"
        />
        
        {/* Recent Tickets */}
        <TicketsList
          tickets={recentTickets}
          isLoading={isLoadingTickets}
          viewAllLink="/client/tickets"
        />
        
        {/* Upcoming Payments */}
        <PaymentsList
          payments={upcomingPayments}
          isLoading={isLoadingInvoices}
          viewAllLink="/client/invoices"
        />
      </div>
      
      {/* Active Projects */}
      <div className="mt-8 bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Active Projects</h3>
          <Link href="/client/tickets">
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-1" />
              New Support Request
            </Button>
          </Link>
        </div>
        <div className="border-t border-gray-200">
          {isLoadingProjects ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : activeProjects.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {activeProjects.map((project) => (
                <div key={project.id} className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="text-lg font-medium text-gray-900">{project.name}</h4>
                      <p className="text-sm text-gray-500 mt-1">{project.description}</p>
                    </div>
                    <StatusBadge status={project.status} />
                  </div>
                  <div className="flex flex-wrap gap-4 mt-4 text-sm text-gray-500">
                    <div>
                      <span className="font-medium">Start Date:</span> {formatDate(project.startDate)}
                    </div>
                    {project.dueDate && (
                      <div>
                        <span className="font-medium">Due Date:</span> {formatDate(project.dueDate)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-500">No active projects</p>
            </div>
          )}
        </div>
        {activeProjects.length > 0 && (
          <div className="bg-gray-50 px-4 py-4 sm:px-6">
            <Link href="/client/websites">
              <a className="text-sm font-medium text-primary hover:text-blue-600 flex items-center">
                View all projects <ChevronRight className="ml-1 h-4 w-4" />
              </a>
            </Link>
          </div>
        )}
      </div>
      
      {/* My Websites */}
      <div className="mt-8 bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900">My Websites</h3>
        </div>
        <div className="border-t border-gray-200">
          {isLoadingWebsites ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : websites && websites.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {websites.slice(0, 3).map((website) => (
                <div key={website.id} className="p-6">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h4 className="text-lg font-medium text-gray-900">{website.name}</h4>
                      <a href={website.url} target="_blank" rel="noopener noreferrer" className="text-sm text-primary flex items-center mt-1">
                        {website.url}
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </a>
                    </div>
                    <StatusBadge status={website.status} />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-xs text-gray-500 mb-1">Uptime</div>
                      <div className="flex items-center">
                        <span className={`mr-2 text-sm font-medium ${
                          parseFloat(website.uptime || "0") > 99 
                            ? "text-green-500" 
                            : parseFloat(website.uptime || "0") > 95 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.uptime || "N/A"}%
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              parseFloat(website.uptime || "0") > 99 
                                ? "bg-green-500" 
                                : parseFloat(website.uptime || "0") > 95 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.uptime || "0"}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-xs text-gray-500 mb-1">Page Speed</div>
                      <div className="flex items-center">
                        <span className={`mr-2 text-sm font-medium ${
                          (website.pageSpeed || 0) > 85 
                            ? "text-green-500" 
                            : (website.pageSpeed || 0) > 70 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.pageSpeed || "N/A"}
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              (website.pageSpeed || 0) > 85 
                                ? "bg-green-500" 
                                : (website.pageSpeed || 0) > 70 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.pageSpeed || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-xs text-gray-500 mb-1">SEO Score</div>
                      <div className="flex items-center">
                        <span className={`mr-2 text-sm font-medium ${
                          (website.seoScore || 0) > 85 
                            ? "text-green-500" 
                            : (website.seoScore || 0) > 70 
                              ? "text-yellow-500" 
                              : "text-red-500"
                        }`}>
                          {website.seoScore || "N/A"}
                        </span>
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              (website.seoScore || 0) > 85 
                                ? "bg-green-500" 
                                : (website.seoScore || 0) > 70 
                                  ? "bg-yellow-500" 
                                  : "bg-red-500"
                            }`}
                            style={{ width: `${website.seoScore || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-500">No websites found</p>
            </div>
          )}
        </div>
        {websites && websites.length > 0 && (
          <div className="bg-gray-50 px-4 py-4 sm:px-6">
            <Link href="/client/websites">
              <a className="text-sm font-medium text-primary hover:text-blue-600 flex items-center">
                View all websites <ChevronRight className="ml-1 h-4 w-4" />
              </a>
            </Link>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
