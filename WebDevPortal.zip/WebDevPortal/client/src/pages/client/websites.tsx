import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/StatusBadge";
import { formatDate, calculateDaysUntil } from "@/lib/utils";
import { 
  Search, 
  ExternalLink, 
  Activity, 
  BarChart, 
  Calendar, 
  AlertTriangle,
  Clock,
  Globe,
  Shield
} from "lucide-react";
import { Website, Project } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export default function ClientWebsites() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("websites");

  const { data: websites, isLoading: isLoadingWebsites } = useQuery({
    queryKey: ["/api/websites"],
  });

  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // Filter websites based on search query
  const filteredWebsites = websites?.filter(website => 
    website.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    website.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
    website.type.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Filter projects based on search query
  const filteredProjects = projects?.filter(project => 
    project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase()))
  ) || [];

  return (
    <DashboardLayout title="My Websites">
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <div className="relative w-72">
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>

        <Button
          variant="outline"
          onClick={() => window.location.href = "/client/tickets"}
        >
          Request Website Update
        </Button>
      </div>

      <Tabs defaultValue="websites" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="websites">Websites</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
        </TabsList>

        <TabsContent value="websites">
          {isLoadingWebsites ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
          ) : filteredWebsites.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredWebsites.map((website: Website) => (
                <Card key={website.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-semibold">{website.name}</h3>
                      <a 
                        href={website.url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-sm text-primary flex items-center"
                      >
                        {website.url}
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </a>
                    </div>
                    <StatusBadge status={website.status} />
                  </div>
                  <CardContent className="p-6">
                    <div className="mb-4">
                      <div className="text-sm text-gray-500">{website.type} Website</div>
                      {website.hostingProvider && (
                        <div className="text-sm text-gray-700 mt-1">
                          <span className="font-medium">Hosting:</span> {website.hostingProvider}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      <div className="bg-gray-50 p-3 rounded-md flex items-center">
                        <Activity className="h-4 w-4 text-primary mr-2" />
                        <div>
                          <div className="text-xs text-gray-500">Uptime</div>
                          <div className="text-sm font-medium">{website.uptime || "N/A"}%</div>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-3 rounded-md flex items-center">
                        <BarChart className="h-4 w-4 text-secondary mr-2" />
                        <div>
                          <div className="text-xs text-gray-500">Page Speed</div>
                          <div className="text-sm font-medium">{website.pageSpeed || "N/A"}/100</div>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-3 rounded-md flex items-center">
                        <BarChart className="h-4 w-4 text-accent mr-2" />
                        <div>
                          <div className="text-xs text-gray-500">SEO Score</div>
                          <div className="text-sm font-medium">{website.seoScore || "N/A"}/100</div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {website.domainExpiryDate && (
                          <div className="flex items-center">
                            <Globe className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div className="text-xs text-gray-500">Domain Expires</div>
                              <div className={`text-sm font-medium ${
                                calculateDaysUntil(website.domainExpiryDate) < 30 
                                  ? "text-red-500" 
                                  : "text-gray-700"
                              }`}>
                                {formatDate(website.domainExpiryDate)}
                                {calculateDaysUntil(website.domainExpiryDate) < 30 && (
                                  <span className="ml-1 text-xs text-red-500">
                                    ({calculateDaysUntil(website.domainExpiryDate)} days)
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {website.sslExpiryDate && (
                          <div className="flex items-center">
                            <Shield className="h-4 w-4 text-gray-400 mr-2" />
                            <div>
                              <div className="text-xs text-gray-500">SSL Expires</div>
                              <div className={`text-sm font-medium ${
                                calculateDaysUntil(website.sslExpiryDate) < 30 
                                  ? "text-red-500" 
                                  : "text-gray-700"
                              }`}>
                                {formatDate(website.sslExpiryDate)}
                                {calculateDaysUntil(website.sslExpiryDate) < 30 && (
                                  <span className="ml-1 text-xs text-red-500">
                                    ({calculateDaysUntil(website.sslExpiryDate)} days)
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <div className="py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 text-blue-500 mb-4">
                  <Globe className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No websites found</h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  {searchQuery 
                    ? "No websites match your search criteria. Try adjusting your search."
                    : "You don't have any websites yet. Contact your account manager to add a website."}
                </p>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="projects">
          {isLoadingProjects ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
          ) : filteredProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProjects.map((project: Project) => (
                <Card key={project.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="text-lg font-semibold line-clamp-1">{project.name}</h3>
                    <StatusBadge status={project.status} />
                  </div>
                  <CardContent className="p-6">
                    {project.description && (
                      <p className="text-sm text-gray-600 mb-4">{project.description}</p>
                    )}

                    <div className="space-y-3">
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-gray-600">Start: {formatDate(project.startDate)}</span>
                      </div>

                      {project.dueDate && (
                        <div className="flex items-center text-sm">
                          <Clock className="h-4 w-4 text-gray-400 mr-2" />
                          <span className={`${
                            calculateDaysUntil(project.dueDate) < 7 && project.status !== "completed"
                              ? "text-amber-600 font-medium"
                              : "text-gray-600"
                          }`}>
                            Due: {formatDate(project.dueDate)}
                            {calculateDaysUntil(project.dueDate) < 7 && project.status !== "completed" && (
                              <span className="ml-2">
                                <AlertTriangle className="h-3.5 w-3.5 inline text-amber-500" />
                              </span>
                            )}
                          </span>
                        </div>
                      )}

                      {project.completedDate && (
                        <div className="flex items-center text-sm">
                          <Calendar className="h-4 w-4 text-green-500 mr-2" />
                          <span className="text-green-600">Completed: {formatDate(project.completedDate)}</span>
                        </div>
                      )}
                    </div>

                    {project.notes && (
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="text-xs uppercase text-gray-500 font-medium mb-1">Notes</div>
                        <p className="text-sm text-gray-700">{project.notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-6 text-center">
              <div className="py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-50 text-purple-500 mb-4">
                  <Activity className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No projects found</h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  {searchQuery 
                    ? "No projects match your search criteria. Try adjusting your search."
                    : "You don't have any active projects at the moment."}
                </p>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
}