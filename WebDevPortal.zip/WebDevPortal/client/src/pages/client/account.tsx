import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Save, User, Building, Mail, Phone, Key, FileText, Package } from "lucide-react";

const profileSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
  companyName: z.string().min(2, "Company name is required"),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(6, "Current password is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Confirm password is required"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

export default function ClientAccount() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  
  const { data: client } = useQuery({
    queryKey: ["/api/clients", user?.id],
    enabled: !!user,
  });
  
  const { data: clientPackages } = useQuery({
    queryKey: ["/api/client-packages"],
    enabled: !!user,
  });
  
  const { data: servicePackages } = useQuery({
    queryKey: ["/api/service-packages"],
    enabled: !!user,
  });
  
  // Set up profile form with user data
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      phone: user?.phone || "",
      companyName: user?.companyName || client?.companyName || "",
    },
  });
  
  // Update the form when user data is loaded
  React.useEffect(() => {
    if (user) {
      profileForm.setValue("name", user.name);
      profileForm.setValue("email", user.email);
      profileForm.setValue("phone", user.phone || "");
      profileForm.setValue("companyName", user.companyName || client?.companyName || "");
    }
  }, [user, client, profileForm]);
  
  // Password form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  // Profile update mutation
  const [updatingProfile, setUpdatingProfile] = useState(false);
  
  const handleProfileUpdate = (data: ProfileFormValues) => {
    setUpdatingProfile(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully",
      });
      setUpdatingProfile(false);
    }, 1000);
  };
  
  // Password update mutation
  const [updatingPassword, setUpdatingPassword] = useState(false);
  
  const handlePasswordUpdate = (data: PasswordFormValues) => {
    setUpdatingPassword(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Password updated",
        description: "Your password has been changed successfully",
      });
      setUpdatingPassword(false);
      passwordForm.reset();
    }, 1000);
  };
  
  // Get service package details
  const getServicePackageDetails = (packageId: number) => {
    return servicePackages?.find(pkg => pkg.id === packageId) || null;
  };
  
  return (
    <DashboardLayout title="My Account">
      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
        </TabsList>
        
        {/* Profile Tab */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your account information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(handleProfileUpdate)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={profileForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input {...field} />
                              <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input {...field} />
                              <Building className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input {...field} />
                              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input {...field} />
                              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button type="submit" disabled={updatingProfile}>
                      {updatingProfile ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>
                Details about your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Account ID</h4>
                  <p className="text-sm">{user?.id}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Username</h4>
                  <p className="text-sm">{user?.username}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Role</h4>
                  <p className="text-sm capitalize">{user?.role}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Account Created</h4>
                  <p className="text-sm">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Unknown"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Security Tab */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>
                Update your password to enhance your account security
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(handlePasswordUpdate)} className="space-y-6">
                  <FormField
                    control={passwordForm.control}
                    name="currentPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input type="password" {...field} />
                            <Key className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={passwordForm.control}
                      name="newPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>New Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormDescription>
                            At least 6 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm New Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button type="submit" disabled={updatingPassword}>
                      {updatingPassword ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        "Update Password"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Login Activity</CardTitle>
              <CardDescription>
                Recent login sessions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-md bg-green-50">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">Current Session</h4>
                      <p className="text-sm text-gray-500">Started: Today, {new Date().toLocaleTimeString()}</p>
                      <p className="text-sm text-gray-500">IP: 127.0.0.1</p>
                    </div>
                    <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                      Active
                    </div>
                  </div>
                </div>
                
                <p className="text-sm text-gray-500 italic">
                  Login history is a demo feature and would normally display real session data.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Subscription Tab */}
        <TabsContent value="subscription">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2 text-primary" />
                Active Subscriptions
              </CardTitle>
              <CardDescription>
                Your current service packages and subscriptions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {clientPackages && clientPackages.length > 0 ? (
                <div className="space-y-6">
                  {clientPackages.map(clientPackage => {
                    const servicePackage = getServicePackageDetails(clientPackage.packageId);
                    return (
                      <div key={clientPackage.id} className="border rounded-md overflow-hidden">
                        <div className="bg-gray-50 px-6 py-4 border-b flex justify-between items-center">
                          <div>
                            <h3 className="font-medium">{servicePackage?.name || `Package #${clientPackage.packageId}`}</h3>
                            <p className="text-sm text-gray-500 capitalize">{servicePackage?.type || "Standard"} Plan</p>
                          </div>
                          <div className={`px-2 py-1 text-xs font-medium rounded-full ${
                            clientPackage.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                          }`}>
                            {clientPackage.isActive ? 'Active' : 'Inactive'}
                          </div>
                        </div>
                        <div className="p-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <h4 className="text-sm font-medium text-gray-500">Start Date</h4>
                              <p className="text-sm">
                                {clientPackage.startDate 
                                  ? new Date(clientPackage.startDate).toLocaleDateString() 
                                  : "N/A"}
                              </p>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium text-gray-500">End Date</h4>
                              <p className="text-sm">
                                {clientPackage.endDate 
                                  ? new Date(clientPackage.endDate).toLocaleDateString() 
                                  : "Ongoing"}
                              </p>
                            </div>
                          </div>
                          
                          {servicePackage?.description && (
                            <div className="mb-4">
                              <h4 className="text-sm font-medium text-gray-500 mb-1">Description</h4>
                              <p className="text-sm">{servicePackage.description}</p>
                            </div>
                          )}
                          
                          {servicePackage?.features && (
                            <div>
                              <h4 className="text-sm font-medium text-gray-500 mb-2">Features</h4>
                              <ul className="text-sm space-y-1">
                                {(typeof servicePackage.features === 'string' 
                                  ? JSON.parse(servicePackage.features) 
                                  : servicePackage.features
                                ).map((feature: string, index: number) => (
                                  <li key={index} className="flex items-start">
                                    <span className="text-green-500 mr-2">✓</span>
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          <div className="mt-4 pt-4 border-t flex justify-between items-center">
                            <div>
                              <span className="font-medium">{servicePackage?.price || "$0.00"}</span>
                              <span className="text-sm text-gray-500"> / month</span>
                            </div>
                            <Button variant="outline">Manage Subscription</Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-md">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">No active subscriptions</h3>
                  <p className="text-gray-500 max-w-md mx-auto">
                    You don't have any active service packages. 
                    Contact your account manager to discuss service options.
                  </p>
                  <Button variant="outline" className="mt-4">Contact Support</Button>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Additional Services</CardTitle>
              <CardDescription>
                Other services that might be of interest
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="border rounded-md p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-medium mb-2">SEO Optimization</h3>
                  <p className="text-sm text-gray-500 mb-3">
                    Improve your website's search engine rankings
                  </p>
                  <Button variant="outline" size="sm" className="w-full">Learn More</Button>
                </div>
                
                <div className="border rounded-md p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-medium mb-2">Social Media Management</h3>
                  <p className="text-sm text-gray-500 mb-3">
                    Professional management of your social media accounts
                  </p>
                  <Button variant="outline" size="sm" className="w-full">Learn More</Button>
                </div>
                
                <div className="border rounded-md p-4 hover:shadow-md transition-shadow">
                  <h3 className="font-medium mb-2">Content Creation</h3>
                  <p className="text-sm text-gray-500 mb-3">
                    High-quality content tailored to your brand
                  </p>
                  <Button variant="outline" size="sm" className="w-full">Learn More</Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <p className="text-sm text-gray-500">
                Contact your account manager to add these services to your package.
              </p>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
}

import React from "react";
