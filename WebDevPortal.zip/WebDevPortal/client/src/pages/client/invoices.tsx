import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/StatusBadge";
import { formatCurrency, formatDate, formatTimeAgo } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Download, 
  CreditCard, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  RefreshCcw, 
  FileText, 
  Loader2, 
  Info
} from "lucide-react";
import { Invoice } from "@shared/schema";

export default function ClientInvoices() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const { toast } = useToast();
  
  const { data: invoices, isLoading } = useQuery({
    queryKey: ["/api/invoices"],
  });
  
  // Filter invoices based on search query and status
  const filteredInvoices = invoices?.filter(invoice => {
    const matchesSearch = 
      invoice.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.amount.toString().includes(searchQuery);
    
    const matchesStatus = !statusFilter || invoice.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  }) || [];
  
  // Group invoices by status for stats
  const invoiceStats = invoices ? {
    total: invoices.length,
    paid: invoices.filter(inv => inv.status === "paid").length,
    pending: invoices.filter(inv => inv.status === "sent").length,
    overdue: invoices.filter(inv => inv.status === "overdue").length,
  } : { total: 0, paid: 0, pending: 0, overdue: 0 };
  
  // Calculate total paid and total pending
  const totalPaid = invoices
    ? invoices
        .filter(inv => inv.status === "paid")
        .reduce((sum, inv) => sum + parseFloat(inv.amount), 0)
    : 0;
  
  const totalPending = invoices
    ? invoices
        .filter(inv => inv.status === "sent" || inv.status === "overdue")
        .reduce((sum, inv) => sum + parseFloat(inv.amount), 0)
    : 0;
  
  const payInvoiceMutation = useMutation({
    mutationFn: async (invoiceId: number) => {
      const res = await apiRequest("PATCH", `/api/invoices/${invoiceId}`, { status: "paid" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Payment successful",
        description: "Your invoice has been marked as paid",
      });
      setSelectedInvoice(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Payment failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handlePayInvoice = (invoice: Invoice) => {
    if (invoice.status === "paid") return;
    
    setPaymentLoading(true);
    
    // Simulate payment processing
    setTimeout(() => {
      payInvoiceMutation.mutate(invoice.id);
      setPaymentLoading(false);
    }, 1500);
  };
  
  // Split invoices by status for tabs
  const unpaidInvoices = filteredInvoices.filter(inv => 
    inv.status === "sent" || inv.status === "overdue"
  );
  const paidInvoices = filteredInvoices.filter(inv => inv.status === "paid");
  const allInvoices = filteredInvoices;
  
  return (
    <DashboardLayout title="Invoices">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500">Total Invoices</p>
                <h3 className="text-2xl font-bold mt-1">{invoiceStats.total}</h3>
              </div>
              <div className="bg-blue-100 p-2 rounded-full">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500">Paid Invoices</p>
                <h3 className="text-2xl font-bold mt-1">{formatCurrency(totalPaid)}</h3>
                <p className="text-xs text-gray-500 mt-1">{invoiceStats.paid} invoices</p>
              </div>
              <div className="bg-green-100 p-2 rounded-full">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500">Pending Payment</p>
                <h3 className="text-2xl font-bold mt-1">{formatCurrency(totalPending)}</h3>
                <p className="text-xs text-gray-500 mt-1">{invoiceStats.pending} invoices</p>
              </div>
              <div className="bg-yellow-100 p-2 rounded-full">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500">Overdue</p>
                <h3 className="text-2xl font-bold mt-1">{invoiceStats.overdue}</h3>
                <p className="text-xs text-gray-500 mt-1">
                  {invoiceStats.overdue > 0 ? "Requires attention" : "No overdue invoices"}
                </p>
              </div>
              <div className="bg-red-100 p-2 rounded-full">
                <Calendar className="h-5 w-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <div className="relative w-72">
          <Input
            placeholder="Search invoices..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
      </div>
      
      <Tabs defaultValue="unpaid" className="mb-6">
        <TabsList>
          <TabsTrigger value="unpaid">Unpaid</TabsTrigger>
          <TabsTrigger value="paid">Paid</TabsTrigger>
          <TabsTrigger value="all">All Invoices</TabsTrigger>
        </TabsList>
        
        {/* Unpaid Invoices Tab */}
        <TabsContent value="unpaid">
          <Card>
            <CardHeader>
              <CardTitle>Unpaid Invoices</CardTitle>
              <CardDescription>
                Invoices awaiting payment
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={6}>
                            <Skeleton className="h-10 w-full" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : unpaidInvoices.length > 0 ? (
                      unpaidInvoices.map((invoice: Invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell>
                            <div className="font-medium">#{invoice.id}</div>
                            <div className="text-xs text-gray-500">
                              {invoice.description || `Invoice #${invoice.id}`}
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(invoice.createdAt)}</TableCell>
                          <TableCell>{formatDate(invoice.dueDate)}</TableCell>
                          <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                          <TableCell>
                            <StatusBadge status={invoice.status} />
                          </TableCell>
                          <TableCell className="text-right">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm"
                                  onClick={() => setSelectedInvoice(invoice)}
                                >
                                  Pay Now
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-md">
                                <DialogHeader>
                                  <DialogTitle>Invoice #{invoice?.id}</DialogTitle>
                                </DialogHeader>
                                {selectedInvoice && (
                                  <div className="space-y-4">
                                    <div className="bg-gray-50 p-4 rounded-md">
                                      <div className="grid grid-cols-2 gap-4">
                                        <div>
                                          <p className="text-sm text-gray-500">Invoice Date</p>
                                          <p className="font-medium">{formatDate(selectedInvoice.createdAt)}</p>
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Due Date</p>
                                          <p className="font-medium">{formatDate(selectedInvoice.dueDate)}</p>
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Status</p>
                                          <StatusBadge status={selectedInvoice.status} />
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Amount</p>
                                          <p className="font-medium text-lg">{formatCurrency(selectedInvoice.amount)}</p>
                                        </div>
                                      </div>
                                      {selectedInvoice.description && (
                                        <div className="mt-4 pt-4 border-t border-gray-200">
                                          <p className="text-sm text-gray-500">Description</p>
                                          <p className="text-sm">{selectedInvoice.description}</p>
                                        </div>
                                      )}
                                    </div>
                                    
                                    <div className="border rounded-md p-4">
                                      <h4 className="font-medium mb-3">Payment Method</h4>
                                      <div className="flex items-center space-x-2 p-2 border rounded-md bg-gray-50">
                                        <CreditCard className="h-5 w-5 text-blue-500" />
                                        <div className="flex-1">
                                          <p className="font-medium">Credit Card</p>
                                          <p className="text-xs text-gray-500">Secure payment via Stripe</p>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div className="flex items-center text-sm text-amber-600 bg-amber-50 p-3 rounded-md">
                                      <Info className="h-4 w-4 mr-2 flex-shrink-0" />
                                      <p>
                                        This is a demo. In a real application, you would be redirected to a payment processor.
                                      </p>
                                    </div>
                                  </div>
                                )}
                                <DialogFooter>
                                  <Button
                                    variant="outline"
                                    onClick={() => setSelectedInvoice(null)}
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    onClick={() => selectedInvoice && handlePayInvoice(selectedInvoice)}
                                    disabled={paymentLoading || payInvoiceMutation.isPending}
                                  >
                                    {paymentLoading || payInvoiceMutation.isPending ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Processing...
                                      </>
                                    ) : (
                                      <>
                                        Pay {selectedInvoice && formatCurrency(selectedInvoice.amount)}
                                      </>
                                    )}
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <div className="flex flex-col items-center justify-center">
                            <CheckCircle2 className="h-10 w-10 text-green-500 mb-2" />
                            <p className="text-gray-500">No unpaid invoices</p>
                            <p className="text-sm text-gray-400">You're all caught up!</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Paid Invoices Tab */}
        <TabsContent value="paid">
          <Card>
            <CardHeader>
              <CardTitle>Paid Invoices</CardTitle>
              <CardDescription>
                Invoices that have been paid
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Paid Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={6}>
                            <Skeleton className="h-10 w-full" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : paidInvoices.length > 0 ? (
                      paidInvoices.map((invoice: Invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell>
                            <div className="font-medium">#{invoice.id}</div>
                            <div className="text-xs text-gray-500">
                              {invoice.description || `Invoice #${invoice.id}`}
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(invoice.createdAt)}</TableCell>
                          <TableCell>{formatDate(invoice.paidAt)}</TableCell>
                          <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                          <TableCell>
                            <StatusBadge status={invoice.status} />
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4 mr-1" />
                              Receipt
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <FileText className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                          <p className="text-gray-500">No paid invoices</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* All Invoices Tab */}
        <TabsContent value="all">
          <Card>
            <CardHeader>
              <CardTitle>All Invoices</CardTitle>
              <CardDescription>
                Complete invoice history
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Due/Paid Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array(3).fill(0).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={6}>
                            <Skeleton className="h-10 w-full" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : allInvoices.length > 0 ? (
                      allInvoices.map((invoice: Invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell>
                            <div className="font-medium">#{invoice.id}</div>
                            <div className="text-xs text-gray-500">
                              {invoice.description || `Invoice #${invoice.id}`}
                              {invoice.isRecurring && (
                                <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded-full">
                                  Recurring
                                </span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(invoice.createdAt)}</TableCell>
                          <TableCell>
                            {invoice.status === "paid" 
                              ? formatDate(invoice.paidAt) 
                              : formatDate(invoice.dueDate)}
                          </TableCell>
                          <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                          <TableCell>
                            <StatusBadge status={invoice.status} />
                          </TableCell>
                          <TableCell className="text-right">
                            {invoice.status === "paid" ? (
                              <Button variant="outline" size="sm">
                                <Download className="h-4 w-4 mr-1" />
                                Receipt
                              </Button>
                            ) : (
                              <Button 
                                size="sm"
                                onClick={() => {
                                  setSelectedInvoice(invoice);
                                  document.getElementById(`pay-invoice-${invoice.id}`)?.click();
                                }}
                              >
                                Pay Now
                              </Button>
                            )}
                            {/* Hidden trigger for dialog */}
                            <Dialog>
                              <DialogTrigger asChild>
                                <button id={`pay-invoice-${invoice.id}`} className="hidden">Pay</button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-md">
                                <DialogHeader>
                                  <DialogTitle>Invoice #{selectedInvoice?.id}</DialogTitle>
                                </DialogHeader>
                                {selectedInvoice && (
                                  <div className="space-y-4">
                                    <div className="bg-gray-50 p-4 rounded-md">
                                      <div className="grid grid-cols-2 gap-4">
                                        <div>
                                          <p className="text-sm text-gray-500">Invoice Date</p>
                                          <p className="font-medium">{formatDate(selectedInvoice.createdAt)}</p>
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Due Date</p>
                                          <p className="font-medium">{formatDate(selectedInvoice.dueDate)}</p>
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Status</p>
                                          <StatusBadge status={selectedInvoice.status} />
                                        </div>
                                        <div>
                                          <p className="text-sm text-gray-500">Amount</p>
                                          <p className="font-medium text-lg">{formatCurrency(selectedInvoice.amount)}</p>
                                        </div>
                                      </div>
                                      {selectedInvoice.description && (
                                        <div className="mt-4 pt-4 border-t border-gray-200">
                                          <p className="text-sm text-gray-500">Description</p>
                                          <p className="text-sm">{selectedInvoice.description}</p>
                                        </div>
                                      )}
                                    </div>
                                    
                                    <div className="border rounded-md p-4">
                                      <h4 className="font-medium mb-3">Payment Method</h4>
                                      <div className="flex items-center space-x-2 p-2 border rounded-md bg-gray-50">
                                        <CreditCard className="h-5 w-5 text-blue-500" />
                                        <div className="flex-1">
                                          <p className="font-medium">Credit Card</p>
                                          <p className="text-xs text-gray-500">Secure payment via Stripe</p>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <div className="flex items-center text-sm text-amber-600 bg-amber-50 p-3 rounded-md">
                                      <Info className="h-4 w-4 mr-2 flex-shrink-0" />
                                      <p>
                                        This is a demo. In a real application, you would be redirected to a payment processor.
                                      </p>
                                    </div>
                                  </div>
                                )}
                                <DialogFooter>
                                  <Button
                                    variant="outline"
                                    onClick={() => setSelectedInvoice(null)}
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    onClick={() => selectedInvoice && handlePayInvoice(selectedInvoice)}
                                    disabled={paymentLoading || payInvoiceMutation.isPending}
                                  >
                                    {paymentLoading || payInvoiceMutation.isPending ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Processing...
                                      </>
                                    ) : (
                                      <>
                                        Pay {selectedInvoice && formatCurrency(selectedInvoice.amount)}
                                      </>
                                    )}
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          <FileText className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                          <p className="text-gray-500">No invoices found</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {invoices?.some(inv => inv.isRecurring) && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <RefreshCcw className="h-5 w-5 mr-2 text-blue-500" />
              Recurring Payments
            </CardTitle>
            <CardDescription>
              Your active subscription services
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {invoices
                .filter(inv => inv.isRecurring)
                .slice(0, 3)
                .map(invoice => (
                  <div key={invoice.id} className="flex justify-between items-center p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">{invoice.description || `Subscription #${invoice.id}`}</h4>
                      <p className="text-sm text-gray-500">
                        {invoice.recurringInterval || "Monthly"} - Next payment on {formatDate(invoice.dueDate)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{formatCurrency(invoice.amount)}</p>
                      <StatusBadge 
                        status="active" 
                        className="bg-green-100 text-green-800 mt-1"
                      />
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </DashboardLayout>
  );
}
