import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/layouts/Dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { StatusBadge } from "@/components/StatusBadge";
import { formatTimeAgo } from "@/lib/utils";
import { Loader2, PlusCircle, Search, MessageSquareText, AlertCircle } from "lucide-react";
import { Ticket, TicketComment, Website } from "@shared/schema";

const createTicketSchema = z.object({
  websiteId: z.string().optional().transform(value => value ? parseInt(value) : undefined),
  title: z.string().min(3, "Title is required and must be at least 3 characters"),
  description: z.string().min(5, "Description is required and must be at least 5 characters"),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
});

type CreateTicketFormValues = z.infer<typeof createTicketSchema>;

export default function ClientTickets() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [commentContent, setCommentContent] = useState("");
  const { toast } = useToast();
  
  const { data: tickets, isLoading: isLoadingTickets } = useQuery({
    queryKey: ["/api/tickets"],
  });
  
  const { data: websites } = useQuery({
    queryKey: ["/api/websites"],
  });
  
  const { data: ticketDetails, isLoading: isLoadingTicketDetails } = useQuery({
    queryKey: ["/api/tickets", selectedTicket?.id],
    enabled: !!selectedTicket,
  });
  
  // Filter tickets based on search query and status
  const filteredTickets = tickets?.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = !statusFilter || ticket.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  }) || [];
  
  const createTicketForm = useForm<CreateTicketFormValues>({
    resolver: zodResolver(createTicketSchema),
    defaultValues: {
      websiteId: "",
      title: "",
      description: "",
      priority: "medium",
    },
  });
  
  const createTicketMutation = useMutation({
    mutationFn: async (data: CreateTicketFormValues) => {
      const res = await apiRequest("POST", "/api/tickets", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      toast({
        title: "Ticket created",
        description: "Your support ticket has been created successfully",
      });
      setIsCreatingTicket(false);
      createTicketForm.reset();
      // Automatically select the new ticket
      setSelectedTicket(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const addCommentMutation = useMutation({
    mutationFn: async ({ ticketId, content }: { ticketId: number, content: string }) => {
      const res = await apiRequest("POST", `/api/tickets/${ticketId}/comments`, { content });
      return res.json();
    },
    onSuccess: () => {
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ["/api/tickets", selectedTicket.id] });
        queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
        setCommentContent("");
        toast({
          title: "Comment added",
          description: "Your comment has been added to the ticket",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error adding comment",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updateTicketMutation = useMutation({
    mutationFn: async ({ ticketId, status }: { ticketId: number, status: string }) => {
      const res = await apiRequest("PATCH", `/api/tickets/${ticketId}`, { status });
      return res.json();
    },
    onSuccess: () => {
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ["/api/tickets", selectedTicket.id] });
        queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
        toast({
          title: "Ticket updated",
          description: "The ticket status has been updated",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onCreateTicket = (data: CreateTicketFormValues) => {
    createTicketMutation.mutate(data);
  };
  
  const handleAddComment = () => {
    if (!selectedTicket || !commentContent.trim()) return;
    
    addCommentMutation.mutate({
      ticketId: selectedTicket.id,
      content: commentContent
    });
  };
  
  const handleCloseTicket = () => {
    if (!selectedTicket) return;
    
    updateTicketMutation.mutate({
      ticketId: selectedTicket.id,
      status: "closed"
    });
  };
  
  return (
    <DashboardLayout title="Support Tickets">
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <div className="flex flex-wrap gap-4">
          <div className="relative w-64">
            <Input
              placeholder="Search tickets..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          
          <Select
            value={statusFilter || ""}
            onValueChange={(value) => setStatusFilter(value || null)}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Statuses</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Dialog open={isCreatingTicket} onOpenChange={setIsCreatingTicket}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-blue-600">
              <PlusCircle className="mr-2 h-4 w-4" />
              New Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Create Support Ticket</DialogTitle>
            </DialogHeader>
            <Form {...createTicketForm}>
              <form onSubmit={createTicketForm.handleSubmit(onCreateTicket)} className="space-y-4">
                <FormField
                  control={createTicketForm.control}
                  name="websiteId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Website (Optional)</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value?.toString() || ""}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a website" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {websites?.map((website: Website) => (
                            <SelectItem key={website.id} value={website.id.toString()}>
                              {website.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={createTicketForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ticket Title</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g., Website Contact Form Not Working" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={createTicketForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please describe the issue in detail..." 
                          className="min-h-[120px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={createTicketForm.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter className="mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreatingTicket(false)}
                    className="mr-2"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createTicketMutation.isPending}
                  >
                    {createTicketMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Submit Ticket"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Your Tickets</CardTitle>
              <CardDescription>
                {filteredTickets.length} ticket{filteredTickets.length !== 1 ? 's' : ''}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingTickets ? (
                <div className="p-4 space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ) : filteredTickets.length > 0 ? (
                <div className="divide-y divide-gray-200">
                  {filteredTickets.map((ticket) => (
                    <div 
                      key={ticket.id}
                      className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                        selectedTicket?.id === ticket.id ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedTicket(ticket)}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-medium text-sm">#{ticket.id}: {ticket.title}</h4>
                        <StatusBadge status={ticket.status} />
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-2 mb-2">{ticket.description}</p>
                      <div className="flex justify-between items-center text-xs text-gray-500">
                        <div>
                          <span className={`inline-block mr-2 px-1.5 py-0.5 rounded ${
                            ticket.priority === 'urgent' ? 'bg-red-100 text-red-800' :
                            ticket.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                            ticket.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                          </span>
                        </div>
                        <div>{formatTimeAgo(ticket.updatedAt)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center">
                  <MessageSquareText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No tickets found</p>
                  {searchQuery || statusFilter ? (
                    <p className="text-sm text-gray-400 mt-1">Try adjusting your filters</p>
                  ) : (
                    <Button 
                      variant="link" 
                      className="mt-2"
                      onClick={() => setIsCreatingTicket(true)}
                    >
                      Create your first support ticket
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Ticket Details */}
        <div className="lg:col-span-2">
          {selectedTicket ? (
            <Card>
              <CardHeader className="border-b">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>#{selectedTicket.id}: {selectedTicket.title}</CardTitle>
                    <CardDescription>Created {formatTimeAgo(selectedTicket.createdAt)}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <StatusBadge status={selectedTicket.priority} />
                    <StatusBadge status={selectedTicket.status} />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-gray-50 p-4 rounded-md mb-6">
                  <p className="text-gray-700 whitespace-pre-line">{selectedTicket.description}</p>
                </div>
                
                <h4 className="font-medium text-sm mb-4">Conversation</h4>
                
                {isLoadingTicketDetails ? (
                  <div className="space-y-4">
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : ticketDetails?.comments && ticketDetails.comments.length > 0 ? (
                  <div className="space-y-4 mb-6">
                    {ticketDetails.comments.map((comment: TicketComment) => (
                      <div key={comment.id} className="bg-gray-50 p-4 rounded-md">
                        <div className="flex justify-between items-start mb-2">
                          <div className="font-medium text-sm">
                            {/* In a real app, this would show the user's name */}
                            {comment.userId === selectedTicket.clientId ? 'You' : 'Support Agent'}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatTimeAgo(comment.createdAt)}
                          </div>
                        </div>
                        <p className="text-gray-700 whitespace-pre-line">{comment.content}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-6 bg-gray-50 rounded-md mb-6">
                    <AlertCircle className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500">No replies yet</p>
                    <p className="text-sm text-gray-400">Support will respond as soon as possible</p>
                  </div>
                )}
                
                {selectedTicket.status !== 'closed' && (
                  <div className="space-y-4">
                    <Textarea 
                      placeholder="Add a comment..."
                      value={commentContent}
                      onChange={(e) => setCommentContent(e.target.value)}
                      className="min-h-[100px]"
                    />
                    <div className="flex justify-between">
                      <Button
                        variant="outline"
                        onClick={handleCloseTicket}
                        disabled={updateTicketMutation.isPending}
                      >
                        {updateTicketMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          "Close Ticket"
                        )}
                      </Button>
                      <Button
                        onClick={handleAddComment}
                        disabled={!commentContent.trim() || addCommentMutation.isPending}
                      >
                        {addCommentMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Sending...
                          </>
                        ) : (
                          "Add Comment"
                        )}
                      </Button>
                    </div>
                  </div>
                )}
                
                {selectedTicket.status === 'closed' && (
                  <div className="text-center p-4 bg-gray-50 rounded-md">
                    <p className="text-gray-500">This ticket is closed</p>
                    <Button
                      variant="link"
                      onClick={() => setIsCreatingTicket(true)}
                      className="mt-2"
                    >
                      Create a new ticket
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="flex flex-col items-center justify-center h-full bg-gray-50 rounded-lg p-8">
              <MessageSquareText className="h-16 w-16 text-gray-300 mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">No ticket selected</h3>
              <p className="text-gray-500 text-center mb-4">
                Select a ticket from the list or create a new one to view details
              </p>
              <Button onClick={() => setIsCreatingTicket(true)}>
                <PlusCircle className="mr-2 h-4 w-4" />
                Create New Ticket
              </Button>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
