import {
  users, User, InsertUser,
  clients, Client, InsertClient,
  websites, Website, InsertWebsite,
  projects, Project, InsertProject,
  servicePackages, ServicePackage, InsertServicePackage,
  clientPackages, ClientPackage, InsertClientPackage,
  tickets, Ticket, InsertTicket,
  ticketComments, TicketComment, InsertTicketComment,
  invoices, Invoice, InsertInvoice,
  alerts, Alert, InsertAlert
} from "@shared/schema";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { eq, and } from "drizzle-orm";
import { db, pool } from "./db";
import createMemoryStore from "memorystore";

// Create PostgreSQL session store
const PostgresSessionStore = connectPgSimple(session);
// Create memory store for testing purposes
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store
  sessionStore: any; // Using any as a workaround for the session store type

  // User Management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  listUsers(): Promise<User[]>;

  // Client Management
  getClient(id: number): Promise<Client | undefined>;
  getClientByUserId(userId: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, clientData: Partial<Client>): Promise<Client | undefined>;
  listClients(): Promise<Client[]>;

  // Website Management
  getWebsite(id: number): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, websiteData: Partial<Website>): Promise<Website | undefined>;
  listWebsites(): Promise<Website[]>;
  listWebsitesByClientId(clientId: number): Promise<Website[]>;

  // Project Management
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined>;
  listProjects(): Promise<Project[]>;
  listProjectsByClientId(clientId: number): Promise<Project[]>;

  // Service Packages
  getServicePackage(id: number): Promise<ServicePackage | undefined>;
  createServicePackage(servicePackage: InsertServicePackage): Promise<ServicePackage>;
  updateServicePackage(id: number, packageData: Partial<ServicePackage>): Promise<ServicePackage | undefined>;
  listServicePackages(): Promise<ServicePackage[]>;

  // Client Packages
  getClientPackage(id: number): Promise<ClientPackage | undefined>;
  createClientPackage(clientPackage: InsertClientPackage): Promise<ClientPackage>;
  updateClientPackage(id: number, packageData: Partial<ClientPackage>): Promise<ClientPackage | undefined>;
  listClientPackages(): Promise<ClientPackage[]>;
  listClientPackagesByClientId(clientId: number): Promise<ClientPackage[]>;

  // Ticket Management
  getTicket(id: number): Promise<Ticket | undefined>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: number, ticketData: Partial<Ticket>): Promise<Ticket | undefined>;
  listTickets(): Promise<Ticket[]>;
  listTicketsByClientId(clientId: number): Promise<Ticket[]>;

  // Ticket Comments
  getTicketComment(id: number): Promise<TicketComment | undefined>;
  createTicketComment(comment: InsertTicketComment): Promise<TicketComment>;
  listTicketCommentsByTicketId(ticketId: number): Promise<TicketComment[]>;

  // Invoice Management
  getInvoice(id: number): Promise<Invoice | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, invoiceData: Partial<Invoice>): Promise<Invoice | undefined>;
  listInvoices(): Promise<Invoice[]>;
  listInvoicesByClientId(clientId: number): Promise<Invoice[]>;

  // Alert Management
  getAlert(id: number): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: number, alertData: Partial<Alert>): Promise<Alert | undefined>;
  listAlerts(): Promise<Alert[]>;
  listAlertsByClientId(clientId: number): Promise<Alert[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clients: Map<number, Client>;
  private websites: Map<number, Website>;
  private projects: Map<number, Project>;
  private servicePackages: Map<number, ServicePackage>;
  private clientPackages: Map<number, ClientPackage>;
  private tickets: Map<number, Ticket>;
  private ticketComments: Map<number, TicketComment>;
  private invoices: Map<number, Invoice>;
  private alerts: Map<number, Alert>;
  
  sessionStore: any; // Using any as a workaround for the session store type
  currentId: {
    users: number;
    clients: number;
    websites: number;
    projects: number;
    servicePackages: number;
    clientPackages: number;
    tickets: number;
    ticketComments: number;
    invoices: number;
    alerts: number;
  };

  constructor() {
    this.users = new Map();
    this.clients = new Map();
    this.websites = new Map();
    this.projects = new Map();
    this.servicePackages = new Map();
    this.clientPackages = new Map();
    this.tickets = new Map();
    this.ticketComments = new Map();
    this.invoices = new Map();
    this.alerts = new Map();
    
    // Use memorystore for session storage
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    this.currentId = {
      users: 1,
      clients: 1,
      websites: 1,
      projects: 1,
      servicePackages: 1,
      clientPackages: 1,
      tickets: 1,
      ticketComments: 1,
      invoices: 1,
      alerts: 1,
    };
  }

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now,
      role: insertUser.role || "client", 
      companyName: insertUser.companyName || null,
      phone: insertUser.phone || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async listUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Client Management
  async getClient(id: number): Promise<Client | undefined> {
    return this.clients.get(id);
  }

  async getClientByUserId(userId: number): Promise<Client | undefined> {
    return Array.from(this.clients.values()).find(
      (client) => client.userId === userId,
    );
  }

  async createClient(client: InsertClient): Promise<Client> {
    const id = this.currentId.clients++;
    const newClient: Client = { ...client, id };
    this.clients.set(id, newClient);
    return newClient;
  }

  async updateClient(id: number, clientData: Partial<Client>): Promise<Client | undefined> {
    const client = this.clients.get(id);
    if (!client) return undefined;
    
    const updatedClient = { ...client, ...clientData };
    this.clients.set(id, updatedClient);
    return updatedClient;
  }

  async listClients(): Promise<Client[]> {
    return Array.from(this.clients.values());
  }

  // Website Management
  async getWebsite(id: number): Promise<Website | undefined> {
    return this.websites.get(id);
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const id = this.currentId.websites++;
    const newWebsite: Website = { ...website, id };
    this.websites.set(id, newWebsite);
    return newWebsite;
  }

  async updateWebsite(id: number, websiteData: Partial<Website>): Promise<Website | undefined> {
    const website = this.websites.get(id);
    if (!website) return undefined;
    
    const updatedWebsite = { ...website, ...websiteData };
    this.websites.set(id, updatedWebsite);
    return updatedWebsite;
  }

  async listWebsites(): Promise<Website[]> {
    return Array.from(this.websites.values());
  }

  async listWebsitesByClientId(clientId: number): Promise<Website[]> {
    return Array.from(this.websites.values()).filter(
      (website) => website.clientId === clientId,
    );
  }

  // Project Management
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.currentId.projects++;
    const newProject: Project = { ...project, id, completedDate: null };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { ...project, ...projectData };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async listProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async listProjectsByClientId(clientId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.clientId === clientId,
    );
  }

  // Service Packages
  async getServicePackage(id: number): Promise<ServicePackage | undefined> {
    return this.servicePackages.get(id);
  }

  async createServicePackage(servicePackage: InsertServicePackage): Promise<ServicePackage> {
    const id = this.currentId.servicePackages++;
    const newPackage: ServicePackage = { ...servicePackage, id };
    this.servicePackages.set(id, newPackage);
    return newPackage;
  }

  async updateServicePackage(id: number, packageData: Partial<ServicePackage>): Promise<ServicePackage | undefined> {
    const packageItem = this.servicePackages.get(id);
    if (!packageItem) return undefined;
    
    const updatedPackage = { ...packageItem, ...packageData };
    this.servicePackages.set(id, updatedPackage);
    return updatedPackage;
  }

  async listServicePackages(): Promise<ServicePackage[]> {
    return Array.from(this.servicePackages.values());
  }

  // Client Packages
  async getClientPackage(id: number): Promise<ClientPackage | undefined> {
    return this.clientPackages.get(id);
  }

  async createClientPackage(clientPackage: InsertClientPackage): Promise<ClientPackage> {
    const id = this.currentId.clientPackages++;
    const newClientPackage: ClientPackage = { ...clientPackage, id };
    this.clientPackages.set(id, newClientPackage);
    return newClientPackage;
  }

  async updateClientPackage(id: number, packageData: Partial<ClientPackage>): Promise<ClientPackage | undefined> {
    const clientPackage = this.clientPackages.get(id);
    if (!clientPackage) return undefined;
    
    const updatedClientPackage = { ...clientPackage, ...packageData };
    this.clientPackages.set(id, updatedClientPackage);
    return updatedClientPackage;
  }

  async listClientPackages(): Promise<ClientPackage[]> {
    return Array.from(this.clientPackages.values());
  }

  async listClientPackagesByClientId(clientId: number): Promise<ClientPackage[]> {
    return Array.from(this.clientPackages.values()).filter(
      (clientPackage) => clientPackage.clientId === clientId,
    );
  }

  // Ticket Management
  async getTicket(id: number): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const id = this.currentId.tickets++;
    const now = new Date();
    const newTicket: Ticket = { ...ticket, id, createdAt: now, updatedAt: now };
    this.tickets.set(id, newTicket);
    return newTicket;
  }

  async updateTicket(id: number, ticketData: Partial<Ticket>): Promise<Ticket | undefined> {
    const ticket = this.tickets.get(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, ...ticketData, updatedAt: new Date() };
    this.tickets.set(id, updatedTicket);
    return updatedTicket;
  }

  async listTickets(): Promise<Ticket[]> {
    return Array.from(this.tickets.values());
  }

  async listTicketsByClientId(clientId: number): Promise<Ticket[]> {
    return Array.from(this.tickets.values()).filter(
      (ticket) => ticket.clientId === clientId,
    );
  }

  // Ticket Comments
  async getTicketComment(id: number): Promise<TicketComment | undefined> {
    return this.ticketComments.get(id);
  }

  async createTicketComment(comment: InsertTicketComment): Promise<TicketComment> {
    const id = this.currentId.ticketComments++;
    const now = new Date();
    const newComment: TicketComment = { ...comment, id, createdAt: now };
    this.ticketComments.set(id, newComment);
    return newComment;
  }

  async listTicketCommentsByTicketId(ticketId: number): Promise<TicketComment[]> {
    return Array.from(this.ticketComments.values()).filter(
      (comment) => comment.ticketId === ticketId,
    );
  }

  // Invoice Management
  async getInvoice(id: number): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const id = this.currentId.invoices++;
    const now = new Date();
    const newInvoice: Invoice = { ...invoice, id, createdAt: now, paidAt: null };
    this.invoices.set(id, newInvoice);
    return newInvoice;
  }

  async updateInvoice(id: number, invoiceData: Partial<Invoice>): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice) return undefined;
    
    const updatedInvoice = { ...invoice, ...invoiceData };
    this.invoices.set(id, updatedInvoice);
    return updatedInvoice;
  }

  async listInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values());
  }

  async listInvoicesByClientId(clientId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(
      (invoice) => invoice.clientId === clientId,
    );
  }

  // Alert Management
  async getAlert(id: number): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const id = this.currentId.alerts++;
    const now = new Date();
    const newAlert: Alert = { ...alert, id, createdAt: now };
    this.alerts.set(id, newAlert);
    return newAlert;
  }

  async updateAlert(id: number, alertData: Partial<Alert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, ...alertData };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  async listAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values());
  }

  async listAlertsByClientId(clientId: number): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(
      (alert) => alert.clientId === clientId,
    );
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any as a workaround for the session store type

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
  }

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure required fields are set properly
    const userData = {
      ...insertUser,
      role: insertUser.role || "client",
      companyName: insertUser.companyName || null,
      phone: insertUser.phone || null
    };
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async listUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  // Client Management
  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async getClientByUserId(userId: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.userId, userId));
    return client;
  }

  async createClient(client: InsertClient): Promise<Client> {
    // Ensure required fields are set properly
    const clientData = {
      ...client,
      phone: client.phone || null,
      address: client.address || null,
      notes: client.notes || null
    };
    
    const [newClient] = await db.insert(clients).values(clientData).returning();
    return newClient;
  }

  async updateClient(id: number, clientData: Partial<Client>): Promise<Client | undefined> {
    const [updatedClient] = await db.update(clients)
      .set(clientData)
      .where(eq(clients.id, id))
      .returning();
    return updatedClient;
  }

  async listClients(): Promise<Client[]> {
    return db.select().from(clients);
  }

  // Website Management
  async getWebsite(id: number): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    return website;
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const [newWebsite] = await db.insert(websites).values(website).returning();
    return newWebsite;
  }

  async updateWebsite(id: number, websiteData: Partial<Website>): Promise<Website | undefined> {
    const [updatedWebsite] = await db.update(websites)
      .set(websiteData)
      .where(eq(websites.id, id))
      .returning();
    return updatedWebsite;
  }

  async listWebsites(): Promise<Website[]> {
    return db.select().from(websites);
  }

  async listWebsitesByClientId(clientId: number): Promise<Website[]> {
    return db.select().from(websites).where(eq(websites.clientId, clientId));
  }

  // Project Management
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values({
      ...project,
      completedDate: null
    }).returning();
    return newProject;
  }

  async updateProject(id: number, projectData: Partial<Project>): Promise<Project | undefined> {
    const [updatedProject] = await db.update(projects)
      .set(projectData)
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async listProjects(): Promise<Project[]> {
    return db.select().from(projects);
  }

  async listProjectsByClientId(clientId: number): Promise<Project[]> {
    return db.select().from(projects).where(eq(projects.clientId, clientId));
  }

  // Service Packages
  async getServicePackage(id: number): Promise<ServicePackage | undefined> {
    const [servicePackage] = await db.select().from(servicePackages).where(eq(servicePackages.id, id));
    return servicePackage;
  }

  async createServicePackage(servicePackage: InsertServicePackage): Promise<ServicePackage> {
    const [newPackage] = await db.insert(servicePackages).values(servicePackage).returning();
    return newPackage;
  }

  async updateServicePackage(id: number, packageData: Partial<ServicePackage>): Promise<ServicePackage | undefined> {
    const [updatedPackage] = await db.update(servicePackages)
      .set(packageData)
      .where(eq(servicePackages.id, id))
      .returning();
    return updatedPackage;
  }

  async listServicePackages(): Promise<ServicePackage[]> {
    return db.select().from(servicePackages);
  }

  // Client Packages
  async getClientPackage(id: number): Promise<ClientPackage | undefined> {
    const [clientPackage] = await db.select().from(clientPackages).where(eq(clientPackages.id, id));
    return clientPackage;
  }

  async createClientPackage(clientPackage: InsertClientPackage): Promise<ClientPackage> {
    const [newClientPackage] = await db.insert(clientPackages).values(clientPackage).returning();
    return newClientPackage;
  }

  async updateClientPackage(id: number, packageData: Partial<ClientPackage>): Promise<ClientPackage | undefined> {
    const [updatedClientPackage] = await db.update(clientPackages)
      .set(packageData)
      .where(eq(clientPackages.id, id))
      .returning();
    return updatedClientPackage;
  }

  async listClientPackages(): Promise<ClientPackage[]> {
    return db.select().from(clientPackages);
  }

  async listClientPackagesByClientId(clientId: number): Promise<ClientPackage[]> {
    return db.select().from(clientPackages).where(eq(clientPackages.clientId, clientId));
  }

  // Ticket Management
  async getTicket(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket;
  }

  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const now = new Date();
    const [newTicket] = await db.insert(tickets).values({
      ...ticket,
      createdAt: now,
      updatedAt: now
    }).returning();
    return newTicket;
  }

  async updateTicket(id: number, ticketData: Partial<Ticket>): Promise<Ticket | undefined> {
    const now = new Date();
    const [updatedTicket] = await db.update(tickets)
      .set({
        ...ticketData,
        updatedAt: now
      })
      .where(eq(tickets.id, id))
      .returning();
    return updatedTicket;
  }

  async listTickets(): Promise<Ticket[]> {
    return db.select().from(tickets);
  }

  async listTicketsByClientId(clientId: number): Promise<Ticket[]> {
    return db.select().from(tickets).where(eq(tickets.clientId, clientId));
  }

  // Ticket Comments
  async getTicketComment(id: number): Promise<TicketComment | undefined> {
    const [comment] = await db.select().from(ticketComments).where(eq(ticketComments.id, id));
    return comment;
  }

  async createTicketComment(comment: InsertTicketComment): Promise<TicketComment> {
    const now = new Date();
    const [newComment] = await db.insert(ticketComments).values({
      ...comment,
      createdAt: now
    }).returning();
    return newComment;
  }

  async listTicketCommentsByTicketId(ticketId: number): Promise<TicketComment[]> {
    return db.select().from(ticketComments).where(eq(ticketComments.ticketId, ticketId));
  }

  // Invoice Management
  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice;
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const now = new Date();
    const [newInvoice] = await db.insert(invoices).values({
      ...invoice,
      createdAt: now,
      paidAt: null
    }).returning();
    return newInvoice;
  }

  async updateInvoice(id: number, invoiceData: Partial<Invoice>): Promise<Invoice | undefined> {
    const [updatedInvoice] = await db.update(invoices)
      .set(invoiceData)
      .where(eq(invoices.id, id))
      .returning();
    return updatedInvoice;
  }

  async listInvoices(): Promise<Invoice[]> {
    return db.select().from(invoices);
  }

  async listInvoicesByClientId(clientId: number): Promise<Invoice[]> {
    return db.select().from(invoices).where(eq(invoices.clientId, clientId));
  }

  // Alert Management
  async getAlert(id: number): Promise<Alert | undefined> {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, id));
    return alert;
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const now = new Date();
    const [newAlert] = await db.insert(alerts).values({
      ...alert,
      createdAt: now
    }).returning();
    return newAlert;
  }

  async updateAlert(id: number, alertData: Partial<Alert>): Promise<Alert | undefined> {
    const [updatedAlert] = await db.update(alerts)
      .set(alertData)
      .where(eq(alerts.id, id))
      .returning();
    return updatedAlert;
  }

  async listAlerts(): Promise<Alert[]> {
    return db.select().from(alerts);
  }

  async listAlertsByClientId(clientId: number): Promise<Alert[]> {
    return db.select().from(alerts).where(eq(alerts.clientId, clientId));
  }
}

export const storage = new DatabaseStorage();
