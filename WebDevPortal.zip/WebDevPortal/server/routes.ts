import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertClientSchema, 
  insertWebsiteSchema, 
  insertProjectSchema, 
  insertTicketSchema, 
  insertInvoiceSchema, 
  insertServicePackageSchema,
  insertClientPackageSchema,
  insertTicketCommentSchema,
  insertAlertSchema 
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Middleware to check if user is authenticated
  const isAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Middleware to check if user is an admin
  const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user.role === "admin") {
      return next();
    }
    res.status(403).json({ message: "Forbidden" });
  };

  // Middleware to check if user is a client or admin
  const isClientOrAdmin = (req, res, next) => {
    if (req.isAuthenticated()) {
      if (req.user.role === "admin") {
        return next();
      }

      // Check if the requested resource belongs to the client
      const resourceId = req.params.id ? parseInt(req.params.id) : null; // Handle missing id
      const clientId = req.params.clientId ? parseInt(req.params.clientId) : null; // Handle missing clientId

      if (req.user.role === "client") {
        storage.getClientByUserId(req.user.id).then(client => {
          if (client) {
            // If clientId is specified in the route, verify it matches client's ID
            if (clientId && client.id !== clientId) {
              return res.status(403).json({ message: "Forbidden" });
            }

            // For resource-specific requests, verify the resource belongs to the client
            if (resourceId && (req.originalUrl.includes("/websites/") || 
                req.originalUrl.includes("/projects/") ||
                req.originalUrl.includes("/tickets/") ||
                req.originalUrl.includes("/invoices/") ||
                req.originalUrl.includes("/alerts/"))) {

              // Logic to check ownership will differ based on resource type
              // This is simplified for the example
              return next();
            }

            return next();
          }
          res.status(403).json({ message: "Forbidden" });
        });
      }
    } else {
      res.status(401).json({ message: "Unauthorized" });
    }
  };

  // API Routes

  // Client Management
  app.get("/api/clients", isAdmin, async (req, res) => {
    try {
      const clients = await storage.listClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:id", isClientOrAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const client = await storage.getClient(id);
    const projects = await storage.listProjectsByClientId(id);
    const websites = await storage.listWebsitesByClientId(id);
    const tickets = await storage.listTicketsByClientId(id);

    if (!client) {
      return res.status(404).json({ message: "Client not found" });
    }

    res.json({ client, projects, websites, tickets });
  } catch (error) {
    res.status(500).json({ message: "Internal server error" });
  }
});
  app.post("/api/clients", isAdmin, async (req, res) => {
    try {
      const clientData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(clientData);
      res.status(201).json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/clients/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingClient = await storage.getClient(id);

      if (!existingClient) {
        return res.status(404).json({ message: "Client not found" });
      }

      const updatedClient = await storage.updateClient(id, req.body);
      res.json(updatedClient);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Website Management
  app.get("/api/websites", isAuthenticated, async (req, res) => {
    try {
      let websites;

      if (req.user.role === "admin") {
        websites = await storage.listWebsites();
      } else {
        // If user is a client, only return their websites
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        websites = await storage.listWebsitesByClientId(client.id);
      }

      res.json(websites);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/websites", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const websites = await storage.listWebsitesByClientId(clientId);
      res.json(websites);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/websites/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const website = await storage.getWebsite(id);

      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }

      // Check if user has access to this website
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || website.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      res.json(website);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/websites", isAdmin, async (req, res) => {
    try {
      const websiteData = insertWebsiteSchema.parse(req.body);
      const website = await storage.createWebsite(websiteData);
      res.status(201).json(website);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/websites/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingWebsite = await storage.getWebsite(id);

      if (!existingWebsite) {
        return res.status(404).json({ message: "Website not found" });
      }

      const updatedWebsite = await storage.updateWebsite(id, req.body);
      res.json(updatedWebsite);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Project Management
  app.get("/api/projects", isAuthenticated, async (req, res) => {
    try {
      let projects;

      if (req.user.role === "admin") {
        projects = await storage.listProjects();
      } else {
        // If user is a client, only return their projects
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        projects = await storage.listProjectsByClientId(client.id);
      }

      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/projects", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const projects = await storage.listProjectsByClientId(clientId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);

      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Check if user has access to this project
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || project.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/projects", isAdmin, async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/projects/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingProject = await storage.getProject(id);

      if (!existingProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      const updatedProject = await storage.updateProject(id, req.body);
      res.json(updatedProject);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Service Packages
  app.get("/api/service-packages", isAuthenticated, async (req, res) => {
    try {
      const packages = await storage.listServicePackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/service-packages/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const servicePackage = await storage.getServicePackage(id);

      if (!servicePackage) {
        return res.status(404).json({ message: "Service package not found" });
      }

      res.json(servicePackage);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/service-packages", isAdmin, async (req, res) => {
    try {
      const packageData = insertServicePackageSchema.parse(req.body);
      const servicePackage = await storage.createServicePackage(packageData);
      res.status(201).json(servicePackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/service-packages/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingPackage = await storage.getServicePackage(id);

      if (!existingPackage) {
        return res.status(404).json({ message: "Service package not found" });
      }

      const updatedPackage = await storage.updateServicePackage(id, req.body);
      res.json(updatedPackage);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client Packages
  app.get("/api/client-packages", isAuthenticated, async (req, res) => {
    try {
      let clientPackages;

      if (req.user.role === "admin") {
        clientPackages = await storage.listClientPackages();
      } else {
        // If user is a client, only return their packages
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        clientPackages = await storage.listClientPackagesByClientId(client.id);
      }

      res.json(clientPackages);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/packages", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const clientPackages = await storage.listClientPackagesByClientId(clientId);
      res.json(clientPackages);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/client-packages", isAdmin, async (req, res) => {
    try {
      const packageData = insertClientPackageSchema.parse(req.body);
      const clientPackage = await storage.createClientPackage(packageData);
      res.status(201).json(clientPackage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/client-packages/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingPackage = await storage.getClientPackage(id);

      if (!existingPackage) {
        return res.status(404).json({ message: "Client package not found" });
      }

      const updatedPackage = await storage.updateClientPackage(id, req.body);
      res.json(updatedPackage);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Ticket Management
  app.get("/api/tickets", isAuthenticated, async (req, res) => {
    try {
      let tickets;

      if (req.user.role === "admin") {
        tickets = await storage.listTickets();
      } else {
        // If user is a client, only return their tickets
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        tickets = await storage.listTicketsByClientId(client.id);
      }

      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/tickets", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const tickets = await storage.listTicketsByClientId(clientId);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/tickets/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const ticket = await storage.getTicket(id);

      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      // Check if user has access to this ticket
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || ticket.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      const comments = await storage.listTicketCommentsByTicketId(id);
      res.json({ ticket, comments });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/tickets", isAuthenticated, async (req, res) => {
    try {
      let ticketData = req.body;

      // If client is creating a ticket, set clientId from their user record
      if (req.user.role === "client") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        ticketData.clientId = client.id;
      }

      const parsedData = insertTicketSchema.parse(ticketData);
      const ticket = await storage.createTicket(parsedData);
      res.status(201).json(ticket);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/tickets/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingTicket = await storage.getTicket(id);

      if (!existingTicket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      // Check if user has access to update this ticket
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || existingTicket.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }

        // Clients can only update certain fields
        const allowedFields = ["description", "status"];
        const forbiddenUpdate = Object.keys(req.body).some(key => !allowedFields.includes(key));

        if (forbiddenUpdate) {
          return res.status(403).json({ message: "You don't have permission to update these fields" });
        }
      }

      const updatedTicket = await storage.updateTicket(id, req.body);
      res.json(updatedTicket);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Ticket Comments
  app.post("/api/tickets/:ticketId/comments", isAuthenticated, async (req, res) => {
    try {
      const ticketId = parseInt(req.params.ticketId);
      const ticket = await storage.getTicket(ticketId);

      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      // Check if user has access to this ticket
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || ticket.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      const commentData = {
        ...req.body,
        ticketId,
        userId: req.user.id
      };

      const parsedData = insertTicketCommentSchema.parse(commentData);
      const comment = await storage.createTicketComment(parsedData);

      // Update the ticket's updatedAt timestamp
      await storage.updateTicket(ticketId, { updatedAt: new Date() });

      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Invoice Management
  app.get("/api/invoices", isAuthenticated, async (req, res) => {
    try {
      let invoices;

      if (req.user.role === "admin") {
        invoices = await storage.listInvoices();
      } else {
        // If user is a client, only return their invoices
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        invoices = await storage.listInvoicesByClientId(client.id);
      }

      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/invoices", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const invoices = await storage.listInvoicesByClientId(clientId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);

      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      // Check if user has access to this invoice
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || invoice.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }
      }

      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/invoices", isAdmin, async (req, res) => {
    try {
      const invoiceData = insertInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoice(invoiceData);
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingInvoice = await storage.getInvoice(id);

      if (!existingInvoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      // Check permissions based on role
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || existingInvoice.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }

        // Clients can only update status to "paid"
        if (Object.keys(req.body).length !== 1 || req.body.status !== "paid") {
          return res.status(403).json({ message: "You can only mark invoices as paid" });
        }

        // Set paid date if marking as paid
        if (req.body.status === "paid") {
          req.body.paidAt = new Date();
        }
      }

      const updatedInvoice = await storage.updateInvoice(id, req.body);
      res.json(updatedInvoice);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Alert Management
  app.get("/api/alerts", isAuthenticated, async (req, res) => {
    try {
      let alerts;

      if (req.user.role === "admin") {
        alerts = await storage.listAlerts();
      } else {
        // If user is a client, only return their alerts
        const client = await storage.getClientByUserId(req.user.id);
        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }
        alerts = await storage.listAlertsByClientId(client.id);
      }

      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/clients/:clientId/alerts", isClientOrAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const alerts = await storage.listAlertsByClientId(clientId);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/alerts", isAdmin, async (req, res) => {
    try {
      const alertData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(alertData);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/alerts/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existingAlert = await storage.getAlert(id);

      if (!existingAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }

      // Check permissions based on role
      if (req.user.role !== "admin") {
        const client = await storage.getClientByUserId(req.user.id);
        if (!client || existingAlert.clientId !== client.id) {
          return res.status(403).json({ message: "Forbidden" });
        }

        // Clients can only update the isRead field
        if (Object.keys(req.body).length !== 1 || !("isRead" in req.body)) {
          return res.status(403).json({ message: "You can only mark alerts as read" });
        }
      }

      const updatedAlert = await storage.updateAlert(id, req.body);
      res.json(updatedAlert);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User Management (admin only)
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.listUsers();

      // Remove passwords from the response
      const sanitizedUsers = users.map(({ password, ...user }) => user);

      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Stats for Dashboard
  app.get("/api/stats", isAuthenticated, async (req, res) => {
    try {
      if (req.user.role === "admin") {
        // Admin stats - all clients, projects, tickets
        const clients = await storage.listClients();
        const projects = await storage.listProjects();
        const tickets = await storage.listTickets();
        const websites = await storage.listWebsites();
        const alerts = await storage.listAlerts();

        // Filter active projects
        const activeProjects = projects.filter(project => 
          project.status === "in_progress" || project.status === "planning" || project.status === "review"
        );

        // Filter open tickets
        const openTickets = tickets.filter(ticket => 
          ticket.status === "open" || ticket.status === "in_progress"
        );

        // Filter upcoming expirations (domains, SSL)
        const now = new Date();
        const thirtyDaysFromNow = new Date(now);
        thirtyDaysFromNow.setDate(now.getDate() + 30);

        // Count websites with domain or SSL expiring soon
        const expiringSoon = alerts.filter(alert => 
          (alert.type === "domain_expiry" || alert.type === "ssl_expiry") && 
          alert.dueDate && new Date(alert.dueDate) < thirtyDaysFromNow
        ).length;

        res.json({
          totalClients: clients.length,
          activeProjects: activeProjects.length,
          openTickets: openTickets.length,
          expiringSoon
        });
      } else {
        // Client stats - their projects, tickets
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        const projects = await storage.listProjectsByClientId(client.id);
        const tickets = await storage.listTicketsByClientId(client.id);
        const websites = await storage.listWebsitesByClientId(client.id);
        const invoices = await storage.listInvoicesByClientId(client.id);

        // Filter active projects
        const activeProjects = projects.filter(project => 
          project.status === "in_progress" || project.status === "planning" || project.status === "review"
        );

        // Filter open tickets
        const openTickets = tickets.filter(ticket => 
          ticket.status === "open" || ticket.status === "in_progress"
        );

        // Filter unpaid invoices
        const unpaidInvoices = invoices.filter(invoice =>
          invoice.status === "sent" || invoice.status === "overdue"
        );

        res.json({
          websites: websites.length,
          activeProjects: activeProjects.length,
          openTickets: openTickets.length,
          unpaidInvoices: unpaidInvoices.length
        });
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Alerts API
  app.get("/api/alerts", isAuthenticated, async (req, res) => {
    try {
      // Get client-specific or all alerts based on role
      let alerts = [];

      if (req.user.role === "admin") {
        // Admin sees all alerts
        alerts = await storage.listAlerts();
      } else {
        // Client sees only their alerts
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        alerts = await storage.listAlertsByClientId(client.id);
      }

      // Sort alerts by creation date (newest first)
      alerts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Tickets API
  app.get("/api/tickets", isAuthenticated, async (req, res) => {
    try {
      // Get client-specific or all tickets based on role
      let tickets = [];

      if (req.user.role === "admin") {
        // Admin sees all tickets
        tickets = await storage.listTickets();
      } else {
        // Client sees only their tickets
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        tickets = await storage.listTicketsByClientId(client.id);
      }

      // Sort tickets by last update date (newest first)
      tickets.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

      res.json(tickets);
    } catch (error) {
      console.error("Error fetching tickets:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Websites API
  app.get("/api/websites", isAuthenticated, async (req, res) => {
    try {
      // Get client-specific or all websites based on role
      let websites = [];

      if (req.user.role === "admin") {
        // Admin sees all websites
        websites = await storage.listWebsites();
      } else {
        // Client sees only their websites
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        websites = await storage.listWebsitesByClientId(client.id);
      }

      res.json(websites);
    } catch (error) {
      console.error("Error fetching websites:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Invoices API
  app.get("/api/invoices", isAuthenticated, async (req, res) => {
    try {
      // Get client-specific or all invoices based on role
      let invoices = [];

      if (req.user.role === "admin") {
        // Admin sees all invoices
        invoices = await storage.listInvoices();
      } else {
        // Client sees only their invoices
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        invoices = await storage.listInvoicesByClientId(client.id);
      }

      // Sort invoices by due date (soonest first)
      invoices.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Projects API
  app.get("/api/projects", isAuthenticated, async (req, res) => {
    try {
      // Get client-specific or all projects based on role
      let projects = [];

      if (req.user.role === "admin") {
        // Admin sees all projects
        projects = await storage.listProjects();
      } else {
        // Client sees only their projects
        const client = await storage.getClientByUserId(req.user.id);

        if (!client) {
          return res.status(404).json({ message: "Client not found" });
        }

        projects = await storage.listProjectsByClientId(client.id);
      }

      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}