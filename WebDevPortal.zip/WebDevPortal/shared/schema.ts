import { pgTable, text, serial, integer, boolean, timestamp, json, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['admin', 'client']);
export const projectStatusEnum = pgEnum('project_status', ['planning', 'in_progress', 'review', 'completed', 'on_hold']);
export const ticketStatusEnum = pgEnum('ticket_status', ['open', 'in_progress', 'resolved', 'closed']);
export const ticketPriorityEnum = pgEnum('ticket_priority', ['low', 'medium', 'high', 'urgent']);
export const websiteStatusEnum = pgEnum('website_status', ['healthy', 'warning', 'critical', 'offline']);
export const invoiceStatusEnum = pgEnum('invoice_status', ['draft', 'sent', 'paid', 'overdue', 'cancelled']);
export const alertTypeEnum = pgEnum('alert_type', ['domain_expiry', 'ssl_expiry', 'server_maintenance', 'performance_issue']);
export const packageTypeEnum = pgEnum('package_type', ['basic', 'standard', 'premium', 'custom']);

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  role: userRoleEnum("role").notNull().default('client'),
  companyName: text("company_name"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Clients
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  companyName: text("company_name").notNull(),
  contactPerson: text("contact_person").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  address: text("address"),
  password: text("password"),
  logoUrl: text("logo_url"),
  packageType: packageTypeEnum("package_type").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Websites
export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  url: text("url").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  status: websiteStatusEnum("status").notNull().default('healthy'),
  uptime: text("uptime").default("100.0"),
  pageSpeed: integer("page_speed").default(100),
  seoScore: integer("seo_score").default(100),
  domainExpiryDate: timestamp("domain_expiry_date"),
  sslExpiryDate: timestamp("ssl_expiry_date"),
  hostingProvider: text("hosting_provider"),
  notes: text("notes"),
  dnsRecords: json("dns_records"),
});

// Projects
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  websiteId: integer("website_id").references(() => websites.id),
  name: text("name").notNull(),
  description: text("description"),
  status: projectStatusEnum("status").notNull().default('planning'),
  startDate: timestamp("start_date").notNull(),
  dueDate: timestamp("due_date"),
  serviceExpiryDate: timestamp("service_expiry_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Service Packages
export const servicePackages = pgTable("service_packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: packageTypeEnum("type").notNull(),
  description: text("description"),
  price: text("price").notNull(),
  features: json("features"),
});

// Client Packages
export const clientPackages = pgTable("client_packages", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  packageId: integer("package_id").notNull().references(() => servicePackages.id),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").notNull().default(true),
});

// Tickets
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  websiteId: integer("website_id").references(() => websites.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: ticketStatusEnum("status").notNull().default('open'),
  priority: ticketPriorityEnum("priority").notNull().default('medium'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  assignedTo: integer("assigned_to").references(() => users.id),
});

// Ticket Comments
export const ticketComments = pgTable("ticket_comments", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => tickets.id),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  attachments: json("attachments"),
});

// Invoices
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  amount: text("amount").notNull(),
  status: invoiceStatusEnum("status").notNull().default('draft'),
  dueDate: timestamp("due_date").notNull(),
  description: text("description"),
  items: json("items"),
  isRecurring: boolean("is_recurring").default(false),
  recurringInterval: text("recurring_interval"),
  createdAt: timestamp("created_at").defaultNow(),
  paidAt: timestamp("paid_at"),
});

// Alerts
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  websiteId: integer("website_id").references(() => websites.id),
  type: alertTypeEnum("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  dueDate: timestamp("due_date"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  userId: true
}).extend({
  userId: z.number().optional()
});

export const insertWebsiteSchema = createInsertSchema(websites).omit({
  id: true
});

export const insertProjectSchema = z.object({
  clientId: z.number(),
  name: z.string().min(2, "Name is required"),
  description: z.string().optional(),
  status: z.enum(["planning", "in_progress", "review", "completed", "on_hold"]),
  startDate: z.coerce.date(),
  dueDate: z.coerce.date().optional().nullable(),
  notes: z.string().optional()
});

export const insertServicePackageSchema = createInsertSchema(servicePackages).omit({
  id: true
});

export const insertClientPackageSchema = createInsertSchema(clientPackages).omit({
  id: true
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertTicketCommentSchema = createInsertSchema(ticketComments).omit({
  id: true,
  createdAt: true
});

export const insertInvoiceSchema = z.object({
  clientId: z.number(),
  amount: z.string().min(1, "Amount is required"),
  status: z.enum(["draft", "sent", "paid", "overdue", "cancelled"]),
  dueDate: z.string().transform(str => new Date(str)),
  description: z.string().optional(),
  items: z.array(z.any()).optional(),
  isRecurring: z.boolean().default(false),
  recurringInterval: z.string().optional()
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type Website = typeof websites.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertServicePackage = z.infer<typeof insertServicePackageSchema>;
export type ServicePackage = typeof servicePackages.$inferSelect;

export type InsertClientPackage = z.infer<typeof insertClientPackageSchema>;
export type ClientPackage = typeof clientPackages.$inferSelect;

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

export type InsertTicketComment = z.infer<typeof insertTicketCommentSchema>;
export type TicketComment = typeof ticketComments.$inferSelect;

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;